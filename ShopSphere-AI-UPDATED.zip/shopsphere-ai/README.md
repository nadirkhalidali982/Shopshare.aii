# ShopSphere AI (Frontend)

**Personalized Shopping, Powered by Intelligence.**
A complete ecommerce frontend built with React, TypeScript and Tailwind CSS. It uses only free and open-source tools. There is no backend: all data is mock data that lives in the browser (localStorage).

---

## 1. Chalane ka tarika (Quick start)

**Zaroori:** Node.js LTS (version 18 ya usse naya) install hona chahiye. Download: https://nodejs.org

1. Zip ko extract karo.
2. VS Code kholo: **File → Open Folder** → `shopsphere-ai` folder chuno.
3. **Terminal → New Terminal** kholo aur ye chalao:

```bash
npm install
npm run dev
```

4. Browser mein kholo: **http://localhost:5173**

Doosre commands:

| Command | Kaam |
|---|---|
| `npm run dev` | Development server (live reload) |
| `npm run build` | Production build `dist/` folder mein |
| `npm run preview` | Build ko local par chala ke dekhna |
| `npm run typecheck` | TypeScript errors check karna |

> Internet chahiye: product photos `picsum.photos` se aati hain aur font Google Fonts se. Internet na ho to photos ki jagah colourful gradient + emoji dikhta hai, app phir bhi chalta hai.

---

## 1b. Vercel par deploy karna

`vercel.json` pehle se included hai (isse `/shop`, `/product/e1` jaise links refresh karne par 404 nahi aata). Vercel dashboard mein zip seedha upload nahi hota, in mein se ek tarika use karo:

- **GitHub se:** folder ko GitHub repo mein push karo → vercel.com par **Add New → Project** → repo chuno → **Deploy**. Settings apne-aap Vite detect ho jaati hain (Build: `npm run build`, Output: `dist`).
- **Ya CLI se:** folder mein terminal kholo → `npx vercel` (pehli baar login poochega) → baar baar Enter dabao → production ke liye `npx vercel --prod`.

---

## 2. Demo login aur promo codes

- **Demo login:** `demo@shopsphere.ai` / `Demo@123` (login page par "Fill demo login" button bhi hai). Ya naya account bana lo.
- **Promo codes:** `WELCOME10` (10% off), `FREESHIP` (free shipping)
- **Test card:** `4242 4242 4242 4242`, koi bhi future expiry (jaise `12/30`), CVV `123`. Koi asli payment nahi hota.
- Free shipping ₹999 se upar ke orders par, warna ₹79 shipping.

---

## 3. Features

**Pages:** Home, Shop, Product Detail, Cart, Checkout (3 steps), Order Success, My Orders, Wishlist, Profile, Login, Register, 404.

**AI features (sab browser mein chalte hain, koi paid API nahi):**

- **Personalized recommendations** (`src/utils/recommendations.ts`): har action ka weight hota hai (view = 1, wishlist = 2, cart = 3, purchase = 4). Isse category aur tags par interest profile banti hai. Har product ko interest match + rating + popularity se score milta hai. Jo product pehle kharid liya ya cart mein hai uska score kam hota hai. Naye user ko trending / top-rated dikhta hai. Har card par "Because you viewed ..." jaisa reason dikhta hai.
- **Smart search** (`src/utils/search.ts`, Fuse.js): galat spelling par bhi result milta hai ("shos" → shoes, "hedphons" → headphones). Kuch na mile to "Did you mean ...?" aata hai. Recent searches save hoti hain.
- **AI Shopping Assistant** (floating "Ask AI" button): budget ("under 2000", "between 500 and 2k"), category aur occasion (gift) samajhta hai. Product cards ke saath jawab deta hai. Chat history save hoti hai. Abhi ye rule-based hai, asli LLM nahi.
- **Similar products**: shared tags aur same category se.

**Extra:** dark mode (system theme follow karta hai), mobile-first responsive (360px par test kiya), loading skeletons, toast alerts, error boundary, keyboard + screen-reader friendly, URL mein filters (link share kar sakte ho).

---

## 4. Folder structure

```
shopsphere-ai/
├── index.html, package.json, vite.config.ts, tsconfig*.json
├── public/favicon.svg
└── src/
    ├── main.tsx, App.tsx, index.css
    ├── types/        sab TypeScript types (Product, Order, User...)
    ├── data/         products.ts (24 products), reviews.ts, categories.ts
    ├── api/          mock backend: products, auth, orders, assistant
    ├── store/        Zustand stores: cart, wishlist, auth, orders, behavior, chat, ui
    ├── hooks/        useProducts, useRecommendations, useProductActions, useTheme...
    ├── utils/        recommendations, search, assistantParser, pricing, validators, format
    ├── components/
    │   ├── layout/   Navbar, Footer, MobileMenu, Layout, ProtectedRoute
    │   ├── product/  ProductCard, ProductGrid, FilterSidebar, ProductGallery...
    │   ├── cart/     CartItemRow, OrderSummary, PromoCodeBox
    │   ├── checkout/ Stepper, AddressForm, PaymentForm, ReviewStep
    │   ├── assistant/ AssistantWidget, ChatMessage
    │   └── ui/       Button, Input, Badge, Skeleton, Toast, Modal, EmptyState, ErrorBoundary
    └── pages/        Home, Shop, ProductDetail, Cart, Checkout, OrderSuccess,
                      Orders, Wishlist, Profile, Login, Register, NotFound
```

---

## 5. Backend kaise jodein (baad mein)

Poora app sirf `src/api/` ke functions se data leta hai. Real backend aane par **sirf in files ke andar `fetch()` lagao**, baaki app waisa hi rahega:

| File | Abhi (mock) | Baad mein |
|---|---|---|
| `api/products.ts` | `data/products.ts` se padhta hai | `GET /products`, `GET /products/:id`, `GET /products/:id/reviews` |
| `api/auth.ts` | users localStorage mein | `POST /login`, `POST /register` (hashed password + token) |
| `api/orders.ts` | order object banata hai | `POST /orders` |
| `api/assistant.ts` | rule-based jawab | local LLM (jaise **Ollama**, open-source) ya apna server |

**Assistant ko Ollama se jodna:** `src/api/assistant.ts` mein `getAssistantReply(message)` ka body badlo. Ollama server (`http://localhost:11434/api/chat`) ko product catalogue ka summary + user ka message bhejo, aur jawab ko `{ text, productIds, suggestions }` format mein return karo. Baaki UI mein kuch nahi badalna.

---

## 6. Dhyan rakhne wali baatein (Honest notes)

- Ye **demo frontend** hai. Payment, login aur database **simulated** hain. Passwords localStorage mein bina encryption ke hain, isliye isse as-is production mein mat chalao.
- Card details kabhi save nahi hote (sirf "Card ending 4242" jaisa label order mein jata hai).
- Product photos random placeholder photos hain (products se match nahi karti). Asli photos ke liye `data/products.ts` mein `images` badlo.
- Order status (Placed → Packed → Shipped → Delivered) demo ke liye samay ke hisaab se apne-aap badalta hai.
- Browser ka data clear karne par cart, wishlist aur orders chale jaate hain (Profile page par "Clear all my data" button bhi hai).

---

## 7. Tech stack

Vite 6, React 18, TypeScript (strict), Tailwind CSS v4, React Router 6, Zustand (persist), Fuse.js, lucide-react.

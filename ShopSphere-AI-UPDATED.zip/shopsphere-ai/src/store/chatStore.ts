import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { getAssistantReply } from '../api/assistant'
import type { ChatMessage } from '../types'
import { uid } from '../utils/format'

const MAX_MESSAGES = 40

interface ChatState {
  messages: ChatMessage[]
  typing: boolean
  send: (text: string) => Promise<void>
  clear: () => void
}

export const useChatStore = create<ChatState>()(
  persist(
    (set, get) => ({
      messages: [],
      typing: false,
      send: async (text) => {
        const trimmed = text.trim()
        if (!trimmed || get().typing) return
        const userMessage: ChatMessage = {
          id: uid('msg'),
          role: 'user',
          text: trimmed,
          createdAt: Date.now(),
        }
        set((s) => ({ messages: [...s.messages, userMessage].slice(-MAX_MESSAGES), typing: true }))
        try {
          const reply = await getAssistantReply(trimmed)
          const assistantMessage: ChatMessage = {
            id: uid('msg'),
            role: 'assistant',
            text: reply.text,
            productIds: reply.productIds,
            suggestions: reply.suggestions,
            createdAt: Date.now(),
          }
          set((s) => ({ messages: [...s.messages, assistantMessage].slice(-MAX_MESSAGES) }))
        } catch {
          const errorMessage: ChatMessage = {
            id: uid('msg'),
            role: 'assistant',
            text: 'Sorry, something went wrong on my side. Please try again.',
            createdAt: Date.now(),
          }
          set((s) => ({ messages: [...s.messages, errorMessage] }))
        } finally {
          set({ typing: false })
        }
      },
      clear: () => set({ messages: [] }),
    }),
    {
      name: 'shopsphere-chat',
      partialize: (state) => ({ messages: state.messages }),
    },
  ),
)

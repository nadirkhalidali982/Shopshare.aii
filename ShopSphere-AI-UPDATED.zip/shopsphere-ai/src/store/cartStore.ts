import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { CartItem } from '../types'
import { findPromo } from '../utils/pricing'

export const MAX_QTY = 10

interface CartState {
  items: CartItem[]
  promoCode: string | null
  addItem: (productId: string, quantity?: number, maxQty?: number) => void
  setQuantity: (productId: string, quantity: number, maxQty?: number) => void
  removeItem: (productId: string) => void
  clear: () => void
  /** Returns true if the code is valid and was applied. */
  applyPromo: (code: string) => boolean
  removePromo: () => void
}

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      items: [],
      promoCode: null,
      addItem: (productId, quantity = 1, maxQty = MAX_QTY) =>
        set((state) => {
          const existing = state.items.find((i) => i.productId === productId)
          if (existing) {
            return {
              items: state.items.map((i) =>
                i.productId === productId
                  ? { ...i, quantity: Math.min(maxQty, i.quantity + quantity) }
                  : i,
              ),
            }
          }
          return { items: [...state.items, { productId, quantity: Math.min(maxQty, quantity) }] }
        }),
      setQuantity: (productId, quantity, maxQty = MAX_QTY) =>
        set((state) => ({
          items: state.items.map((i) =>
            i.productId === productId
              ? { ...i, quantity: Math.max(1, Math.min(maxQty, quantity)) }
              : i,
          ),
        })),
      removeItem: (productId) =>
        set((state) => ({ items: state.items.filter((i) => i.productId !== productId) })),
      clear: () => set({ items: [], promoCode: null }),
      applyPromo: (code) => {
        const promo = findPromo(code)
        if (!promo) return false
        set({ promoCode: promo.code })
        return true
      },
      removePromo: () => set({ promoCode: null }),
    }),
    { name: 'shopsphere-cart' },
  ),
)

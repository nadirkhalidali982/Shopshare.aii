import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface WishlistState {
  ids: string[]
  /** Returns true when the product was added, false when it was removed. */
  toggle: (productId: string) => boolean
  remove: (productId: string) => void
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      ids: [],
      toggle: (productId) => {
        const exists = get().ids.includes(productId)
        set((state) => ({
          ids: exists ? state.ids.filter((id) => id !== productId) : [...state.ids, productId],
        }))
        return !exists
      },
      remove: (productId) => set((state) => ({ ids: state.ids.filter((id) => id !== productId) })),
    }),
    { name: 'shopsphere-wishlist' },
  ),
)

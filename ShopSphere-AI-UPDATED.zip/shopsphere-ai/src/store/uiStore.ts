import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { uid } from '../utils/format'

export type Theme = 'light' | 'dark'
export type ToastType = 'success' | 'error' | 'info'

export interface Toast {
  id: string
  message: string
  type: ToastType
}

interface UiState {
  theme: Theme
  toasts: Toast[]
  assistantOpen: boolean
  toggleTheme: () => void
  setTheme: (theme: Theme) => void
  pushToast: (message: string, type?: ToastType) => void
  dismissToast: (id: string) => void
  setAssistantOpen: (open: boolean) => void
}

function systemTheme(): Theme {
  if (typeof window === 'undefined' || !window.matchMedia) return 'light'
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export const useUiStore = create<UiState>()(
  persist(
    (set) => ({
      theme: systemTheme(),
      toasts: [],
      assistantOpen: false,
      toggleTheme: () => set((s) => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),
      setTheme: (theme) => set({ theme }),
      pushToast: (message, type = 'success') => {
        const id = uid('toast')
        set((s) => ({ toasts: [...s.toasts.slice(-3), { id, message, type }] }))
        setTimeout(() => {
          set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }))
        }, 3500)
      },
      dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
      setAssistantOpen: (assistantOpen) => set({ assistantOpen }),
    }),
    {
      name: 'shopsphere-ui',
      // Only the theme is saved; toasts and the open chat panel are temporary.
      partialize: (state) => ({ theme: state.theme }),
    },
  ),
)

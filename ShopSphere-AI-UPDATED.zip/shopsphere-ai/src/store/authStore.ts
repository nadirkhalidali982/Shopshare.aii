import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { loginUser, registerUser, updateUserProfile } from '../api/auth'
import type { User } from '../types'

interface AuthState {
  user: User | null
  /** Throws an Error with a user-friendly message on failure. */
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
  updateUser: (changes: Partial<Omit<User, 'id' | 'email'>>) => Promise<void>
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      login: async (email, password) => {
        const user = await loginUser(email, password)
        set({ user })
      },
      register: async (name, email, password) => {
        const user = await registerUser(name, email, password)
        set({ user })
      },
      logout: () => set({ user: null }),
      updateUser: async (changes) => {
        const current = get().user
        if (!current) return
        // Update the UI state immediately, then sync the (mock) server copy.
        const merged = { ...current, ...changes }
        set({ user: merged })
        await updateUserProfile(merged)
      },
    }),
    { name: 'shopsphere-auth' },
  ),
)

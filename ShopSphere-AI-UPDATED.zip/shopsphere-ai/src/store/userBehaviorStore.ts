import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { BehaviorAction, BehaviorEvent } from '../types'

const MAX_EVENTS = 300
const MAX_RECENT = 12
const MAX_SEARCHES = 6

interface BehaviorState {
  events: BehaviorEvent[]
  recentlyViewed: string[]
  recentSearches: string[]
  track: (productId: string, action: BehaviorAction) => void
  addSearch: (query: string) => void
  clearSearches: () => void
}

export const useBehaviorStore = create<BehaviorState>()(
  persist(
    (set) => ({
      events: [],
      recentlyViewed: [],
      recentSearches: [],
      track: (productId, action) =>
        set((state) => ({
          events: [...state.events, { productId, action, at: Date.now() }].slice(-MAX_EVENTS),
          recentlyViewed:
            action === 'view'
              ? [productId, ...state.recentlyViewed.filter((id) => id !== productId)].slice(0, MAX_RECENT)
              : state.recentlyViewed,
        })),
      addSearch: (query) =>
        set((state) => {
          const q = query.trim()
          if (!q) return state
          return {
            recentSearches: [q, ...state.recentSearches.filter((s) => s.toLowerCase() !== q.toLowerCase())].slice(
              0,
              MAX_SEARCHES,
            ),
          }
        }),
      clearSearches: () => set({ recentSearches: [] }),
    }),
    { name: 'shopsphere-behavior' },
  ),
)

import { indianStates } from '../../data/indianStates'
import type { Address } from '../../types'
import type { AddressErrors } from '../../utils/validators'
import Input from '../ui/Input'

interface AddressFormProps {
  value: Address
  errors: AddressErrors
  onChange: (changes: Partial<Address>) => void
}

export default function AddressForm({ value, errors, onChange }: AddressFormProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Input
        label="Full name"
        autoComplete="name"
        value={value.fullName}
        error={errors.fullName}
        onChange={(e) => onChange({ fullName: e.target.value })}
      />
      <Input
        label="Mobile number"
        type="tel"
        inputMode="numeric"
        autoComplete="tel-national"
        maxLength={11}
        placeholder="98765 43210"
        value={value.phone}
        error={errors.phone}
        onChange={(e) => onChange({ phone: e.target.value })}
      />
      <Input
        className="sm:col-span-2"
        label="Address"
        autoComplete="street-address"
        placeholder="House no, street, area"
        value={value.line1}
        error={errors.line1}
        onChange={(e) => onChange({ line1: e.target.value })}
      />
      <Input
        label="City"
        autoComplete="address-level2"
        value={value.city}
        error={errors.city}
        onChange={(e) => onChange({ city: e.target.value })}
      />
      <div>
        <label htmlFor="state" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
          State
        </label>
        <select
          id="state"
          autoComplete="address-level1"
          value={value.state}
          aria-invalid={errors.state ? true : undefined}
          onChange={(e) => onChange({ state: e.target.value })}
          className={`h-11 w-full rounded-xl border bg-white px-3 text-sm dark:bg-slate-900 ${
            errors.state ? 'border-red-500' : 'border-slate-300 dark:border-slate-700'
          }`}
        >
          <option value="">Select state</option>
          {indianStates.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        {errors.state && <p className="mt-1 text-xs text-red-600 dark:text-red-400">{errors.state}</p>}
      </div>
      <Input
        label="PIN code"
        inputMode="numeric"
        autoComplete="postal-code"
        maxLength={6}
        placeholder="250001"
        value={value.pincode}
        error={errors.pincode}
        onChange={(e) => onChange({ pincode: e.target.value.replace(/\D/g, '') })}
      />
    </div>
  )
}

import { Check } from 'lucide-react'
import { cn } from '../../utils/format'

interface StepperProps {
  steps: string[]
  current: number
}

export default function Stepper({ steps, current }: StepperProps) {
  return (
    <ol className="flex items-center" aria-label="Checkout progress">
      {steps.map((label, i) => {
        const done = i < current
        const active = i === current
        return (
          <li key={label} className={cn('flex items-center', i < steps.length - 1 && 'flex-1')} aria-current={active ? 'step' : undefined}>
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-bold',
                  done && 'bg-brand-600 text-white',
                  active && 'bg-brand-600 text-white ring-4 ring-brand-200 dark:ring-brand-900',
                  !done && !active && 'bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-400',
                )}
              >
                {done ? <Check className="h-4 w-4" aria-hidden="true" /> : i + 1}
              </span>
              <span
                className={cn(
                  'text-sm font-semibold',
                  active ? 'text-slate-900 dark:text-white' : 'hidden text-slate-500 sm:inline dark:text-slate-400',
                )}
              >
                {label}
              </span>
            </div>
            {i < steps.length - 1 && (
              <div className={cn('mx-3 h-0.5 flex-1 rounded', done ? 'bg-brand-500' : 'bg-slate-200 dark:bg-slate-800')} />
            )}
          </li>
        )
      })}
    </ol>
  )
}

import { Banknote, CreditCard, Smartphone } from 'lucide-react'
import type { PaymentDraft, PaymentMethod } from '../../types'
import { cn } from '../../utils/format'
import type { PaymentErrors } from '../../utils/validators'
import Input from '../ui/Input'

interface PaymentFormProps {
  value: PaymentDraft
  errors: PaymentErrors
  onChange: (changes: Partial<PaymentDraft>) => void
}

const methods: Array<{ id: PaymentMethod; label: string; hint: string; icon: typeof CreditCard }> = [
  { id: 'cod', label: 'Cash on Delivery', hint: 'Pay when it arrives', icon: Banknote },
  { id: 'upi', label: 'UPI', hint: 'GPay, PhonePe, Paytm', icon: Smartphone },
  { id: 'card', label: 'Credit / Debit card', hint: 'Visa, Mastercard, RuPay', icon: CreditCard },
]

function formatCardNumber(raw: string): string {
  return raw
    .replace(/\D/g, '')
    .slice(0, 19)
    .replace(/(.{4})/g, '$1 ')
    .trim()
}

function formatExpiry(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 4)
  return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits
}

export default function PaymentForm({ value, errors, onChange }: PaymentFormProps) {
  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
        This is a demo store. No real payment is taken and card details are never saved.
      </div>

      <fieldset>
        <legend className="sr-only">Payment method</legend>
        <div className="grid gap-3 sm:grid-cols-3">
          {methods.map((m) => {
            const Icon = m.icon
            const selected = value.method === m.id
            return (
              <label
                key={m.id}
                className={cn(
                  'flex cursor-pointer flex-col gap-1 rounded-xl border-2 p-4 transition-colors',
                  selected
                    ? 'border-brand-500 bg-brand-50 dark:bg-brand-900/20'
                    : 'border-slate-200 hover:border-slate-300 dark:border-slate-700 dark:hover:border-slate-600',
                )}
              >
                <input
                  type="radio"
                  name="payment-method"
                  className="sr-only"
                  checked={selected}
                  onChange={() => onChange({ method: m.id })}
                />
                <Icon className={cn('h-5 w-5', selected ? 'text-brand-600 dark:text-brand-300' : 'text-slate-500')} aria-hidden="true" />
                <span className="text-sm font-semibold text-slate-900 dark:text-white">{m.label}</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">{m.hint}</span>
              </label>
            )
          })}
        </div>
      </fieldset>

      {value.method === 'card' && (
        <div className="grid gap-4 sm:grid-cols-2">
          <Input
            className="sm:col-span-2"
            label="Card number"
            inputMode="numeric"
            autoComplete="cc-number"
            placeholder="4242 4242 4242 4242"
            hint="Demo tip: 4242 4242 4242 4242 passes validation"
            value={value.cardNumber}
            error={errors.cardNumber}
            onChange={(e) => onChange({ cardNumber: formatCardNumber(e.target.value) })}
          />
          <Input
            className="sm:col-span-2"
            label="Name on card"
            autoComplete="cc-name"
            value={value.cardName}
            error={errors.cardName}
            onChange={(e) => onChange({ cardName: e.target.value })}
          />
          <Input
            label="Expiry (MM/YY)"
            inputMode="numeric"
            autoComplete="cc-exp"
            placeholder="08/29"
            value={value.expiry}
            error={errors.expiry}
            onChange={(e) => onChange({ expiry: formatExpiry(e.target.value) })}
          />
          <Input
            label="CVV"
            type="password"
            inputMode="numeric"
            autoComplete="cc-csc"
            maxLength={4}
            value={value.cvv}
            error={errors.cvv}
            onChange={(e) => onChange({ cvv: e.target.value.replace(/\D/g, '') })}
          />
        </div>
      )}

      {value.method === 'upi' && (
        <Input
          label="UPI ID"
          autoComplete="off"
          placeholder="yourname@okbank"
          value={value.upiId}
          error={errors.upiId}
          onChange={(e) => onChange({ upiId: e.target.value })}
        />
      )}

      {value.method === 'cod' && (
        <p className="rounded-xl bg-slate-100 px-4 py-3 text-sm text-slate-700 dark:bg-slate-800 dark:text-slate-300">
          Pay in cash or UPI to the delivery partner when your order arrives.
        </p>
      )}
    </div>
  )
}

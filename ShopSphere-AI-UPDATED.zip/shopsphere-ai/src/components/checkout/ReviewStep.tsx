import type { Address, CartLine, PaymentDraft } from '../../types'
import { formatPrice } from '../../utils/format'
import { describePayment } from '../../api/orders'
import ProductImage from '../product/ProductImage'

interface ReviewStepProps {
  lines: CartLine[]
  address: Address
  payment: PaymentDraft
  onEditAddress: () => void
  onEditPayment: () => void
}

function Block({ title, onEdit, children }: { title: string; onEdit: () => void; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-800">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">{title}</h3>
        <button type="button" onClick={onEdit} className="text-sm font-medium text-brand-600 hover:underline dark:text-brand-300">
          Change
        </button>
      </div>
      <div className="text-sm text-slate-600 dark:text-slate-300">{children}</div>
    </div>
  )
}

export default function ReviewStep({ lines, address, payment, onEditAddress, onEditPayment }: ReviewStepProps) {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Block title="Deliver to" onEdit={onEditAddress}>
          <p className="font-semibold text-slate-900 dark:text-white">{address.fullName}</p>
          <p>{address.line1}</p>
          <p>
            {address.city}, {address.state} - {address.pincode}
          </p>
          <p>Mobile: {address.phone}</p>
        </Block>
        <Block title="Payment" onEdit={onEditPayment}>
          <p className="font-semibold text-slate-900 dark:text-white">{describePayment(payment)}</p>
        </Block>
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800">
        <h3 className="border-b border-slate-200 px-4 py-3 text-sm font-bold text-slate-900 dark:border-slate-800 dark:text-white">
          Items ({lines.reduce((n, l) => n + l.quantity, 0)})
        </h3>
        <ul className="divide-y divide-slate-200 dark:divide-slate-800">
          {lines.map(({ product, quantity }) => (
            <li key={product.id} className="flex items-center gap-3 p-4">
              <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800">
                <ProductImage src={product.images[0]} alt={product.name} category={product.category} className="h-full w-full object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-900 dark:text-white">{product.name}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Qty {quantity}</p>
              </div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">{formatPrice(product.price * quantity)}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Bot, Send, Sparkles, Trash2, X } from 'lucide-react'
import { useProducts } from '../../hooks/useProducts'
import { useChatStore } from '../../store/chatStore'
import { useUiStore } from '../../store/uiStore'
import ChatMessage from './ChatMessage'

const STARTERS = ['Gifts under 1500', 'Best headphones', 'Trending now', 'Fitness picks under 3000']

export default function AssistantWidget() {
  const open = useUiStore((s) => s.assistantOpen)
  const setOpen = useUiStore((s) => s.setAssistantOpen)
  const messages = useChatStore((s) => s.messages)
  const typing = useChatStore((s) => s.typing)
  const send = useChatStore((s) => s.send)
  const clear = useChatStore((s) => s.clear)
  const { products } = useProducts()
  const [draft, setDraft] = useState('')
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, typing, open])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!draft.trim()) return
    void send(draft)
    setDraft('')
  }

  const lastAssistant = [...messages].reverse().find((m) => m.role === 'assistant')
  const chips = messages.length === 0 ? STARTERS : (lastAssistant?.suggestions ?? [])

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Open AI shopping assistant"
        className="fixed bottom-4 right-4 z-50 flex h-14 items-center gap-2 rounded-full bg-gradient-to-r from-brand-600 to-ink-800 px-5 font-semibold text-white shadow-xl transition-transform hover:scale-105"
      >
        <Sparkles className="h-5 w-5" aria-hidden="true" />
        <span className="hidden sm:inline">Ask AI</span>
      </button>
    )
  }

  return (
    <section
      aria-label="AI shopping assistant"
      className="fixed inset-x-3 bottom-3 z-50 flex h-[34rem] max-h-[85vh] animate-pop-in flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl sm:inset-x-auto sm:right-4 sm:w-96 dark:border-slate-700 dark:bg-slate-900"
    >
      <header className="flex items-center gap-3 bg-gradient-to-r from-brand-600 to-ink-800 px-4 py-3 text-white">
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/20" aria-hidden="true">
          <Bot className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <h2 className="text-sm font-bold">ShopSphere Assistant</h2>
          <p className="text-xs text-white/80">Tell me your budget and what you like</p>
        </div>
        {messages.length > 0 && (
          <button type="button" onClick={clear} aria-label="Clear conversation" className="rounded-lg p-2 hover:bg-white/15">
            <Trash2 className="h-4 w-4" />
          </button>
        )}
        <button type="button" onClick={() => setOpen(false)} aria-label="Close assistant" className="rounded-lg p-2 hover:bg-white/15">
          <X className="h-5 w-5" />
        </button>
      </header>

      <div className="flex-1 space-y-4 overflow-y-auto p-4" aria-live="polite">
        {messages.length === 0 && (
          <div className="flex gap-2">
            <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white" aria-hidden="true">
              <Bot className="h-4 w-4" />
            </div>
            <p className="max-w-[85%] rounded-2xl rounded-bl-md bg-slate-100 px-3.5 py-2 text-sm text-slate-800 dark:bg-slate-800 dark:text-slate-100">
              Hi! I can find products by budget, category or occasion. What are you shopping for today?
            </p>
          </div>
        )}
        {messages.map((m) => (
          <ChatMessage key={m.id} message={m} products={products} onNavigate={() => setOpen(false)} />
        ))}
        {typing && (
          <div className="flex items-center gap-2 text-sm text-slate-500" role="status">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-600 text-white" aria-hidden="true">
              <Bot className="h-4 w-4" />
            </div>
            <span className="flex gap-1" aria-label="Assistant is typing">
              <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
              <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
              <span className="h-2 w-2 animate-bounce rounded-full bg-slate-400" />
            </span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      {chips.length > 0 && !typing && (
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-2">
          {chips.map((chip) => (
            <button
              key={chip}
              type="button"
              onClick={() => void send(chip)}
              className="shrink-0 rounded-full border border-brand-200 bg-brand-50 px-3 py-1.5 text-xs font-medium text-brand-800 hover:bg-brand-100 dark:border-brand-800 dark:bg-brand-900/30 dark:text-brand-200"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      <form onSubmit={submit} className="flex gap-2 border-t border-slate-200 p-3 dark:border-slate-800">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="e.g. headphones under 3000"
          aria-label="Message the assistant"
          className="h-11 min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3.5 text-sm dark:border-slate-700 dark:bg-slate-950"
        />
        <button
          type="submit"
          disabled={!draft.trim() || typing}
          aria-label="Send message"
          className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand-600 text-white hover:bg-brand-700 disabled:opacity-50"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </section>
  )
}

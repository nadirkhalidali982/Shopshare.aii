import { Link } from 'react-router-dom'
import { Bot, ShoppingCart } from 'lucide-react'
import { useProductActions } from '../../hooks/useProductActions'
import type { ChatMessage as ChatMessageType, Product } from '../../types'
import { cn, formatPrice } from '../../utils/format'
import ProductImage from '../product/ProductImage'

function MiniProduct({ product, onNavigate }: { product: Product; onNavigate: () => void }) {
  const { addToCart } = useProductActions()
  return (
    <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-2.5 dark:border-slate-700 dark:bg-slate-900">
      <Link
        to={`/product/${product.id}`}
        onClick={onNavigate}
        className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800"
        aria-label={`View ${product.name}`}
      >
        <ProductImage src={product.images[0]} alt={product.name} category={product.category} className="h-full w-full object-cover" />
      </Link>
      <div className="min-w-0 flex-1">
        <Link
          to={`/product/${product.id}`}
          onClick={onNavigate}
          className="line-clamp-1 text-sm font-semibold text-slate-900 hover:text-brand-600 dark:text-white"
        >
          {product.name}
        </Link>
        <p className="text-sm font-bold text-brand-700 dark:text-brand-300">{formatPrice(product.price)}</p>
      </div>
      <button
        type="button"
        onClick={() => addToCart(product)}
        aria-label={`Add ${product.name} to cart`}
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white hover:bg-brand-700"
      >
        <ShoppingCart className="h-4 w-4" />
      </button>
    </div>
  )
}

interface ChatMessageProps {
  message: ChatMessageType
  products: Product[]
  onNavigate: () => void
}

export default function ChatMessage({ message, products, onNavigate }: ChatMessageProps) {
  const isUser = message.role === 'user'
  const items = (message.productIds ?? [])
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p))

  return (
    <div className={cn('flex gap-2', isUser ? 'justify-end' : 'justify-start')}>
      {!isUser && (
        <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white" aria-hidden="true">
          <Bot className="h-4 w-4" />
        </div>
      )}
      <div className={cn('max-w-[85%] space-y-2', isUser && 'text-right')}>
        <p
          className={cn(
            'inline-block whitespace-pre-line rounded-2xl px-3.5 py-2 text-left text-sm',
            isUser
              ? 'rounded-br-md bg-brand-600 text-white'
              : 'rounded-bl-md bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-100',
          )}
        >
          {message.text}
        </p>
        {items.length > 0 && (
          <div className="space-y-2 text-left">
            {items.map((p) => (
              <MiniProduct key={p.id} product={p} onNavigate={onNavigate} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

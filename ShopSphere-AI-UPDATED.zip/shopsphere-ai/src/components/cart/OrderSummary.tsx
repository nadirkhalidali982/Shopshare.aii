import type { ReactNode } from 'react'
import { Truck } from 'lucide-react'
import { cn, formatPrice } from '../../utils/format'
import { FREE_SHIPPING_THRESHOLD, type Totals } from '../../utils/pricing'
import PromoCodeBox from './PromoCodeBox'

interface OrderSummaryProps {
  totals: Totals
  showPromo?: boolean
  children?: ReactNode
  className?: string
}

function Row({ label, value, tone }: { label: string; value: string; tone?: 'green' }) {
  return (
    <div className="flex justify-between text-sm">
      <dt className="text-slate-600 dark:text-slate-400">{label}</dt>
      <dd className={cn('font-medium', tone === 'green' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-900 dark:text-slate-100')}>
        {value}
      </dd>
    </div>
  )
}

export default function OrderSummary({ totals, showPromo = true, children, className }: OrderSummaryProps) {
  const progress = Math.min(100, ((FREE_SHIPPING_THRESHOLD - totals.amountToFreeShipping) / FREE_SHIPPING_THRESHOLD) * 100)

  return (
    <div className={cn('space-y-5 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900', className)}>
      <h2 className="text-lg font-bold text-slate-900 dark:text-white">Order summary</h2>

      {totals.amountToFreeShipping > 0 ? (
        <div className="rounded-xl bg-brand-50 p-3 text-sm dark:bg-brand-900/20">
          <p className="flex items-center gap-2 font-medium text-brand-800 dark:text-brand-200">
            <Truck className="h-4 w-4" aria-hidden="true" />
            Add {formatPrice(totals.amountToFreeShipping)} more for free shipping
          </p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-brand-100 dark:bg-brand-900/50">
            <div className="h-full rounded-full bg-brand-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      ) : (
        totals.itemCount > 0 && (
          <p className="flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-sm font-medium text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200">
            <Truck className="h-4 w-4" aria-hidden="true" />
            You get free shipping on this order
          </p>
        )
      )}

      {showPromo && <PromoCodeBox />}

      <dl className="space-y-2.5">
        <Row label={`Subtotal (${totals.itemCount} ${totals.itemCount === 1 ? 'item' : 'items'})`} value={formatPrice(totals.subtotal)} />
        {totals.discount > 0 && <Row label="Promo discount" value={`− ${formatPrice(totals.discount)}`} tone="green" />}
        <Row label="Shipping" value={totals.shipping === 0 ? 'Free' : formatPrice(totals.shipping)} tone={totals.shipping === 0 ? 'green' : undefined} />
        <div className="flex justify-between border-t border-slate-200 pt-3 dark:border-slate-800">
          <dt className="text-base font-bold text-slate-900 dark:text-white">Total</dt>
          <dd className="text-xl font-extrabold text-slate-900 dark:text-white">{formatPrice(totals.total)}</dd>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">Includes GST of {formatPrice(totals.gstIncluded)} (18%).</p>
        {totals.mrpSavings > 0 && (
          <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400">
            You are saving {formatPrice(totals.mrpSavings + totals.discount)} on this order
          </p>
        )}
      </dl>

      {children}
    </div>
  )
}

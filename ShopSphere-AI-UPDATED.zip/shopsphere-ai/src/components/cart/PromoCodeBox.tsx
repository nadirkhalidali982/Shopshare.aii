import { useState, type FormEvent } from 'react'
import { Tag, X } from 'lucide-react'
import { useCartStore } from '../../store/cartStore'
import { useUiStore } from '../../store/uiStore'
import { findPromo } from '../../utils/pricing'
import Button from '../ui/Button'

export default function PromoCodeBox() {
  const promoCode = useCartStore((s) => s.promoCode)
  const applyPromo = useCartStore((s) => s.applyPromo)
  const removePromo = useCartStore((s) => s.removePromo)
  const toast = useUiStore((s) => s.pushToast)
  const [value, setValue] = useState('')
  const [error, setError] = useState('')

  const promo = promoCode ? findPromo(promoCode) : null

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!value.trim()) {
      setError('Enter a promo code')
      return
    }
    if (applyPromo(value)) {
      setError('')
      setValue('')
      toast('Promo code applied')
    } else {
      setError('That code is not valid. Try WELCOME10 or FREESHIP.')
    }
  }

  if (promo) {
    return (
      <div className="flex items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-sm dark:border-emerald-900 dark:bg-emerald-950/40">
        <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-200">
          <Tag className="h-4 w-4" aria-hidden="true" />
          <span>
            <strong>{promo.code}</strong> · {promo.label}
          </span>
        </div>
        <button
          type="button"
          onClick={removePromo}
          aria-label="Remove promo code"
          className="rounded p-1 text-emerald-700 hover:bg-emerald-100 dark:text-emerald-300 dark:hover:bg-emerald-900"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    )
  }

  return (
    <form onSubmit={submit} noValidate>
      <label htmlFor="promo" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
        Promo code
      </label>
      <div className="flex gap-2">
        <input
          id="promo"
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setError('')
          }}
          placeholder="WELCOME10"
          aria-invalid={error ? true : undefined}
          className="h-10 min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3 text-sm uppercase placeholder:normal-case dark:border-slate-700 dark:bg-slate-950"
        />
        <Button type="submit" variant="secondary" size="sm">
          Apply
        </Button>
      </div>
      {error && <p className="mt-1 text-xs text-red-600 dark:text-red-400">{error}</p>}
    </form>
  )
}

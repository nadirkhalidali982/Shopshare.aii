import { Link } from 'react-router-dom'
import { Minus, Plus, Trash2 } from 'lucide-react'
import { MAX_QTY } from '../../store/cartStore'
import type { Product } from '../../types'
import { formatPrice } from '../../utils/format'
import ProductImage from '../product/ProductImage'

interface CartItemRowProps {
  product: Product
  quantity: number
  onQuantityChange: (quantity: number) => void
  onRemove: () => void
}

export default function CartItemRow({ product, quantity, onQuantityChange, onRemove }: CartItemRowProps) {
  const max = Math.min(MAX_QTY, product.stock)
  return (
    <li className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-3 sm:p-4 dark:border-slate-800 dark:bg-slate-900">
      <Link
        to={`/product/${product.id}`}
        className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-slate-100 sm:h-28 sm:w-28 dark:bg-slate-800"
        aria-label={`View ${product.name}`}
      >
        <ProductImage src={product.images[0]} alt={product.name} category={product.category} className="h-full w-full object-cover" />
      </Link>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">{product.brand}</p>
            <Link
              to={`/product/${product.id}`}
              className="line-clamp-2 font-semibold text-slate-900 hover:text-brand-600 dark:text-white dark:hover:text-brand-300"
            >
              {product.name}
            </Link>
          </div>
          <button
            type="button"
            onClick={onRemove}
            aria-label={`Remove ${product.name} from cart`}
            className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-3">
          <div className="inline-flex items-center rounded-xl border border-slate-300 dark:border-slate-700" role="group" aria-label={`Quantity for ${product.name}`}>
            <button
              type="button"
              onClick={() => onQuantityChange(quantity - 1)}
              disabled={quantity <= 1}
              aria-label="Decrease quantity"
              className="flex h-9 w-9 items-center justify-center rounded-l-xl text-slate-700 hover:bg-slate-100 disabled:opacity-40 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="w-10 text-center text-sm font-semibold" aria-live="polite">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => onQuantityChange(quantity + 1)}
              disabled={quantity >= max}
              aria-label="Increase quantity"
              className="flex h-9 w-9 items-center justify-center rounded-r-xl text-slate-700 hover:bg-slate-100 disabled:opacity-40 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
          <div className="text-right">
            <p className="text-lg font-bold text-slate-900 dark:text-white">{formatPrice(product.price * quantity)}</p>
            {quantity > 1 && <p className="text-xs text-slate-500 dark:text-slate-400">{formatPrice(product.price)} each</p>}
          </div>
        </div>
        {quantity >= max && max < MAX_QTY && (
          <p className="mt-1 text-xs text-amber-600 dark:text-amber-400">Only {product.stock} left in stock</p>
        )}
      </div>
    </li>
  )
}

import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom'
import { Heart, LogOut, Menu, Moon, Package, Search, ShoppingCart, Sun, User, X } from 'lucide-react'
import { useAuthStore } from '../../store/authStore'
import { useCartStore } from '../../store/cartStore'
import { useUiStore } from '../../store/uiStore'
import { useWishlistStore } from '../../store/wishlistStore'
import { cn } from '../../utils/format'
import MobileMenu from './MobileMenu'

function CountBadge({ count }: { count: number }) {
  if (count === 0) return null
  return (
    <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand-600 px-1 text-[11px] font-bold text-white">
      {count > 99 ? '99+' : count}
    </span>
  )
}

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2" aria-label="ShopSphere AI home">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-ink-900 text-white">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <circle cx="12" cy="12" r="8" />
          <ellipse cx="12" cy="12" rx="8" ry="3" />
        </svg>
      </span>
      <span className="whitespace-nowrap text-lg font-extrabold tracking-tight text-ink-900 dark:text-white">
        ShopSphere<span className="text-brand-600 dark:text-brand-400"> AI</span>
      </span>
    </Link>
  )
}

const iconButton =
  'relative flex h-10 w-10 items-center justify-center rounded-xl text-slate-700 transition-colors hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800'

export default function Navbar() {
  const navigate = useNavigate()
  const location = useLocation()
  const [query, setQuery] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const userRef = useRef<HTMLDivElement>(null)

  const cartCount = useCartStore((s) => s.items.reduce((n, i) => n + i.quantity, 0))
  const wishCount = useWishlistStore((s) => s.ids.length)
  const user = useAuthStore((s) => s.user)
  const logout = useAuthStore((s) => s.logout)
  const theme = useUiStore((s) => s.theme)
  const toggleTheme = useUiStore((s) => s.toggleTheme)

  // Close menus whenever the page changes.
  useEffect(() => {
    setMenuOpen(false)
    setUserOpen(false)
  }, [location.pathname])

  // Close the user dropdown when clicking elsewhere.
  useEffect(() => {
    if (!userOpen) return
    const onClick = (e: MouseEvent) => {
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [userOpen])

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const q = query.trim()
    navigate(q ? `/shop?q=${encodeURIComponent(q)}` : '/shop')
  }

  const navLink = ({ isActive }: { isActive: boolean }) =>
    cn(
      'rounded-lg px-3 py-2 text-sm font-medium transition-colors',
      isActive
        ? 'text-brand-700 dark:text-brand-300'
        : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white',
    )

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <Logo />

        <nav aria-label="Main" className="ml-4 hidden items-center md:flex">
          <NavLink to="/" end className={navLink}>
            Home
          </NavLink>
          <NavLink to="/shop" className={navLink}>
            Shop
          </NavLink>
        </nav>

        <form onSubmit={submit} role="search" className="relative mx-auto hidden w-full max-w-md md:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products, brands, categories..."
            aria-label="Search products"
            className="h-10 w-full rounded-xl border border-slate-200 bg-slate-100 pl-9 pr-3 text-sm placeholder:text-slate-500 focus:border-brand-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500/30 dark:border-slate-700 dark:bg-slate-800 dark:focus:bg-slate-900"
          />
        </form>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className={cn(iconButton, 'hidden sm:flex')}
          >
            {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>

          <Link to="/wishlist" aria-label={`Wishlist, ${wishCount} items`} className={iconButton}>
            <Heart className="h-5 w-5" />
            <CountBadge count={wishCount} />
          </Link>

          <Link to="/cart" aria-label={`Cart, ${cartCount} items`} className={iconButton}>
            <ShoppingCart className="h-5 w-5" />
            <CountBadge count={cartCount} />
          </Link>

          <div className="relative hidden md:block" ref={userRef}>
            {user ? (
              <>
                <button
                  type="button"
                  onClick={() => setUserOpen((o) => !o)}
                  aria-haspopup="menu"
                  aria-expanded={userOpen}
                  className="ml-1 flex h-10 items-center gap-2 rounded-xl pl-1 pr-3 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-sm font-bold text-white">
                    {user.name.charAt(0).toUpperCase()}
                  </span>
                  <span className="max-w-24 truncate text-sm font-medium">{user.name.split(' ')[0]}</span>
                </button>
                {userOpen && (
                  <div
                    role="menu"
                    className="absolute right-0 mt-2 w-52 animate-pop-in rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-700 dark:bg-slate-900"
                  >
                    <Link role="menuitem" to="/profile" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-800">
                      <User className="h-4 w-4" /> Profile
                    </Link>
                    <Link role="menuitem" to="/orders" className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-slate-100 dark:hover:bg-slate-800">
                      <Package className="h-4 w-4" /> My orders
                    </Link>
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        logout()
                        setUserOpen(false)
                        navigate('/')
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
                    >
                      <LogOut className="h-4 w-4" /> Log out
                    </button>
                  </div>
                )}
              </>
            ) : (
              <Link
                to="/login"
                className="ml-1 inline-flex h-10 items-center rounded-xl bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
              >
                Log in
              </Link>
            )}
          </div>

          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            className={cn(iconButton, 'md:hidden')}
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <MobileMenu open={menuOpen} onClose={() => setMenuOpen(false)} />
    </header>
  )
}

import { Link } from 'react-router-dom'
import { categoryNames } from '../../data/categories'
import { Logo } from './Navbar'

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm text-slate-600 dark:text-slate-400">
            Personalized Shopping, Powered by Intelligence. Smart recommendations, typo-tolerant search and an AI
            assistant that helps you find the right product within your budget.
          </p>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-bold text-slate-900 dark:text-white">Shop</h2>
          <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
            {categoryNames.map((c) => (
              <li key={c}>
                <Link to={`/shop?category=${encodeURIComponent(c)}`} className="hover:text-brand-600 dark:hover:text-brand-300">
                  {c}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-bold text-slate-900 dark:text-white">Account</h2>
          <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
            <li>
              <Link to="/orders" className="hover:text-brand-600 dark:hover:text-brand-300">
                My orders
              </Link>
            </li>
            <li>
              <Link to="/wishlist" className="hover:text-brand-600 dark:hover:text-brand-300">
                Wishlist
              </Link>
            </li>
            <li>
              <Link to="/cart" className="hover:text-brand-600 dark:hover:text-brand-300">
                Cart
              </Link>
            </li>
            <li>
              <Link to="/profile" className="hover:text-brand-600 dark:hover:text-brand-300">
                Profile
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-slate-200 py-5 text-center text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
        © 2026 ShopSphere AI. Demo storefront: payments and accounts are simulated.
        <p className="mt-2 text-[10px] font-medium uppercase tracking-[0.22em] text-slate-400">VALIDAAD THE FOUNDER</p>
      </div>
    </footer>
  )
}

import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Heart, LogIn, LogOut, Moon, Package, Search, ShoppingCart, Sun, User } from 'lucide-react'
import { categoryNames } from '../../data/categories'
import { useAuthStore } from '../../store/authStore'
import { useUiStore } from '../../store/uiStore'

interface MobileMenuProps {
  open: boolean
  onClose: () => void
}

export default function MobileMenu({ open, onClose }: MobileMenuProps) {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const logout = useAuthStore((s) => s.logout)
  const theme = useUiStore((s) => s.theme)
  const toggleTheme = useUiStore((s) => s.toggleTheme)
  const [query, setQuery] = useState('')

  if (!open) return null

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const q = query.trim()
    navigate(q ? `/shop?q=${encodeURIComponent(q)}` : '/shop')
    setQuery('')
    onClose()
  }

  const linkClass =
    'flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800'

  return (
    <nav
      id="mobile-menu"
      aria-label="Mobile menu"
      className="border-t border-slate-200 bg-white px-4 pb-4 pt-3 md:hidden dark:border-slate-800 dark:bg-slate-900"
    >
      <form onSubmit={submit} role="search" className="relative mb-3">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products"
          aria-label="Search products"
          className="h-11 w-full rounded-xl border border-slate-300 bg-slate-50 pl-9 pr-3 text-sm dark:border-slate-700 dark:bg-slate-950"
        />
      </form>

      <div className="mb-3 flex flex-wrap gap-2">
        {categoryNames.map((c) => (
          <Link
            key={c}
            to={`/shop?category=${encodeURIComponent(c)}`}
            onClick={onClose}
            className="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 dark:border-slate-700 dark:text-slate-300"
          >
            {c}
          </Link>
        ))}
      </div>

      <button type="button" onClick={toggleTheme} className={`${linkClass} w-full`}>
        {theme === 'dark' ? <Sun className="h-5 w-5" aria-hidden="true" /> : <Moon className="h-5 w-5" aria-hidden="true" />}
        {theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      </button>
      <Link to="/cart" onClick={onClose} className={linkClass}>
        <ShoppingCart className="h-5 w-5" aria-hidden="true" /> Cart
      </Link>
      <Link to="/wishlist" onClick={onClose} className={linkClass}>
        <Heart className="h-5 w-5" aria-hidden="true" /> Wishlist
      </Link>
      {user ? (
        <>
          <Link to="/orders" onClick={onClose} className={linkClass}>
            <Package className="h-5 w-5" aria-hidden="true" /> My orders
          </Link>
          <Link to="/profile" onClick={onClose} className={linkClass}>
            <User className="h-5 w-5" aria-hidden="true" /> Profile ({user.name})
          </Link>
          <button
            type="button"
            onClick={() => {
              logout()
              onClose()
              navigate('/')
            }}
            className={`${linkClass} w-full`}
          >
            <LogOut className="h-5 w-5" aria-hidden="true" /> Log out
          </button>
        </>
      ) : (
        <Link to="/login" onClick={onClose} className={linkClass}>
          <LogIn className="h-5 w-5" aria-hidden="true" /> Log in / Sign up
        </Link>
      )}
    </nav>
  )
}

import { categoryNames } from '../../data/categories'
import { cn } from '../../utils/format'

export interface ShopFilters {
  category: string
  min: string
  max: string
  rating: number
  inStock: boolean
}

interface FilterSidebarProps {
  filters: ShopFilters
  onChange: (changes: Partial<ShopFilters>) => void
  onReset: () => void
  className?: string
}

const ratingOptions = [4, 3, 2]

export default function FilterSidebar({ filters, onChange, onReset, className }: FilterSidebarProps) {
  const active =
    filters.category !== '' || filters.min !== '' || filters.max !== '' || filters.rating > 0 || filters.inStock

  return (
    <aside
      aria-label="Product filters"
      className={cn(
        'space-y-6 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900',
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold text-slate-900 dark:text-white">Filters</h2>
        {active && (
          <button type="button" onClick={onReset} className="text-sm font-medium text-brand-600 hover:underline dark:text-brand-300">
            Reset all
          </button>
        )}
      </div>

      <fieldset>
        <legend className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-300">Category</legend>
        <div className="space-y-1.5">
          {['', ...categoryNames].map((name) => (
            <label key={name || 'all'} className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input
                type="radio"
                name="category"
                checked={filters.category === name}
                onChange={() => onChange({ category: name })}
                className="h-4 w-4 accent-brand-600"
              />
              {name || 'All categories'}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-300">Price (₹)</legend>
        <div className="flex items-center gap-2">
          <input
            type="number"
            inputMode="numeric"
            min={0}
            placeholder="Min"
            aria-label="Minimum price"
            value={filters.min}
            onChange={(e) => onChange({ min: e.target.value })}
            className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm dark:border-slate-700 dark:bg-slate-950"
          />
          <span className="text-slate-400">–</span>
          <input
            type="number"
            inputMode="numeric"
            min={0}
            placeholder="Max"
            aria-label="Maximum price"
            value={filters.max}
            onChange={(e) => onChange({ max: e.target.value })}
            className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm dark:border-slate-700 dark:bg-slate-950"
          />
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {[500, 1000, 2500, 5000].map((cap) => (
            <button
              key={cap}
              type="button"
              onClick={() => onChange({ min: '', max: String(cap) })}
              className="rounded-full border border-slate-300 px-3 py-1 text-xs text-slate-600 hover:border-brand-500 hover:text-brand-700 dark:border-slate-700 dark:text-slate-300"
            >
              Under ₹{cap.toLocaleString('en-IN')}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-300">Customer rating</legend>
        <div className="space-y-1.5">
          <label className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
            <input
              type="radio"
              name="rating"
              checked={filters.rating === 0}
              onChange={() => onChange({ rating: 0 })}
              className="h-4 w-4 accent-brand-600"
            />
            Any rating
          </label>
          {ratingOptions.map((r) => (
            <label key={r} className="flex cursor-pointer items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
              <input
                type="radio"
                name="rating"
                checked={filters.rating === r}
                onChange={() => onChange({ rating: r })}
                className="h-4 w-4 accent-brand-600"
              />
              {r}★ & up
            </label>
          ))}
        </div>
      </fieldset>

      <label className="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-700 dark:text-slate-300">
        <input
          type="checkbox"
          checked={filters.inStock}
          onChange={(e) => onChange({ inStock: e.target.checked })}
          className="h-4 w-4 accent-brand-600"
        />
        In stock only
      </label>
    </aside>
  )
}

import type { Product } from '../../types'
import { cn } from '../../utils/format'
import { ProductGridSkeleton } from '../ui/Skeleton'
import ProductCard from './ProductCard'

interface ProductGridProps {
  products: Product[]
  loading?: boolean
  /** Product id -> reason text (from recommendations) */
  reasons?: Record<string, string>
  layout?: 'grid' | 'list'
  skeletonCount?: number
  /** Columns on large screens. Defaults to 4. */
  columns?: 3 | 4
}

export default function ProductGrid({
  products,
  loading = false,
  reasons,
  layout = 'grid',
  skeletonCount = 8,
  columns = 4,
}: ProductGridProps) {
  if (loading) return <ProductGridSkeleton count={skeletonCount} />

  if (layout === 'list') {
    return (
      <div className="flex flex-col gap-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} reason={reasons?.[p.id]} layout="list" />
        ))}
      </div>
    )
  }

  return (
    <div
      className={cn(
        'grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3',
        columns === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3',
      )}
    >
      {products.map((p) => (
        <ProductCard key={p.id} product={p} reason={reasons?.[p.id]} />
      ))}
    </div>
  )
}

import { Star } from 'lucide-react'
import { cn } from '../../utils/format'

interface RatingStarsProps {
  rating: number
  count?: number
  size?: 'sm' | 'md'
}

export default function RatingStars({ rating, count, size = 'sm' }: RatingStarsProps) {
  const dim = size === 'sm' ? 'h-3.5 w-3.5' : 'h-5 w-5'
  return (
    <div className="flex items-center gap-1.5" aria-label={`Rated ${rating.toFixed(1)} out of 5`}>
      <div className="flex" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((n) => (
          <Star
            key={n}
            className={cn(
              dim,
              rating >= n - 0.25
                ? 'fill-amber-400 text-amber-400'
                : rating >= n - 0.75
                  ? 'fill-amber-400/50 text-amber-400'
                  : 'fill-transparent text-slate-300 dark:text-slate-600',
            )}
          />
        ))}
      </div>
      <span className={cn('font-semibold text-slate-700 dark:text-slate-200', size === 'sm' ? 'text-xs' : 'text-sm')}>
        {rating.toFixed(1)}
      </span>
      {count !== undefined && (
        <span className={cn('text-slate-500 dark:text-slate-400', size === 'sm' ? 'text-xs' : 'text-sm')}>
          ({count.toLocaleString('en-IN')})
        </span>
      )}
    </div>
  )
}

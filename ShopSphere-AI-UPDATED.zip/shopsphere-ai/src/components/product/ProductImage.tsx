import { useState } from 'react'
import { categoryEmoji, categoryGradient } from '../../data/categories'
import type { Category } from '../../types'
import { cn } from '../../utils/format'

interface ProductImageProps {
  src: string
  alt: string
  category: Category
  className?: string
}

/** Shows the photo, or a colourful gradient with an emoji if it cannot load (offline, blocked...). */
export default function ProductImage({ src, alt, category, className }: ProductImageProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null)

  if (failedSrc === src) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={cn(
          'flex items-center justify-center bg-gradient-to-br text-5xl',
          categoryGradient(category),
          className,
        )}
      >
        <span aria-hidden="true">{categoryEmoji(category)}</span>
      </div>
    )
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      onError={() => setFailedSrc(src)}
      className={className}
    />
  )
}

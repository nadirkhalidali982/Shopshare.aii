import { Link } from 'react-router-dom'
import { Heart, ShoppingCart, Sparkles } from 'lucide-react'
import { useProductActions } from '../../hooks/useProductActions'
import { useWishlistStore } from '../../store/wishlistStore'
import type { Product } from '../../types'
import { cn, discountPercent } from '../../utils/format'
import Badge from '../ui/Badge'
import Button from '../ui/Button'
import PriceTag from './PriceTag'
import ProductImage from './ProductImage'
import RatingStars from './RatingStars'

interface ProductCardProps {
  product: Product
  /** Short "why we picked this" text from the recommendation engine */
  reason?: string
  layout?: 'grid' | 'list'
}

export default function ProductCard({ product, reason, layout = 'grid' }: ProductCardProps) {
  const { addToCart, toggleWishlist } = useProductActions()
  const wished = useWishlistStore((s) => s.ids.includes(product.id))
  const off = discountPercent(product.price, product.originalPrice)
  const soldOut = product.stock === 0
  const isList = layout === 'list'

  return (
    <article
      className={cn(
        'group relative flex overflow-hidden rounded-2xl border border-slate-200 bg-white transition-shadow hover:shadow-lg',
        'dark:border-slate-800 dark:bg-slate-900',
        isList ? 'flex-row' : 'flex-col',
      )}
    >
      <Link
        to={`/product/${product.id}`}
        aria-label={`View ${product.name}`}
        className={cn(
          'relative block shrink-0 overflow-hidden bg-slate-100 dark:bg-slate-800',
          isList ? 'w-36 sm:w-52' : 'aspect-square w-full',
        )}
      >
        <ProductImage
          src={product.images[0]}
          alt={product.name}
          category={product.category}
          className={cn(
            'h-full w-full object-cover transition-transform duration-500 group-hover:scale-105',
            soldOut && 'opacity-60 grayscale',
          )}
        />
        <div className="absolute left-2 top-2 flex flex-col items-start gap-1">
          {off > 0 && <Badge tone="green">{off}% off</Badge>}
          {product.id === 'k1' && <Badge tone="amber">VALIDAAD Priority</Badge>}
          {product.isTrending && !soldOut && product.id !== 'k1' && <Badge tone="amber">Trending</Badge>}
          {soldOut && <Badge tone="red">Out of stock</Badge>}
        </div>
      </Link>

      <button
        type="button"
        onClick={() => toggleWishlist(product)}
        aria-pressed={wished}
        aria-label={wished ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
        className="absolute right-2 top-2 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 shadow-sm backdrop-blur transition-colors hover:bg-white dark:bg-slate-900/90 dark:hover:bg-slate-900"
      >
        <Heart className={cn('h-[18px] w-[18px]', wished ? 'fill-rose-500 text-rose-500' : 'text-slate-600 dark:text-slate-300')} />
      </button>

      <div className="flex min-w-0 flex-1 flex-col gap-1.5 p-3 sm:p-4">
        <p className="truncate text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">
          {product.brand}
        </p>
        <h3 className="line-clamp-2 text-sm font-semibold leading-snug text-slate-900 dark:text-white sm:text-base">
          <Link to={`/product/${product.id}`} className="hover:text-brand-600 dark:hover:text-brand-300">
            {product.name}
          </Link>
        </h3>
        <RatingStars rating={product.rating} count={product.reviewCount} />
        {isList && (
          <p className="line-clamp-2 hidden text-sm text-slate-500 dark:text-slate-400 sm:block">{product.description}</p>
        )}
        {reason && (
          <p className="flex items-start gap-1 text-xs font-medium text-brand-700 dark:text-brand-300">
            <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
            <span className="line-clamp-2">{reason}</span>
          </p>
        )}
        <div className="mt-auto pt-2">
          <PriceTag price={product.price} originalPrice={product.originalPrice} />
          <Button
            size="sm"
            className="mt-3 w-full"
            variant={soldOut ? 'secondary' : 'primary'}
            disabled={soldOut}
            onClick={() => addToCart(product)}
          >
            <ShoppingCart className="h-4 w-4" aria-hidden="true" />
            {soldOut ? 'Sold out' : 'Add to cart'}
          </Button>
        </div>
      </div>
    </article>
  )
}

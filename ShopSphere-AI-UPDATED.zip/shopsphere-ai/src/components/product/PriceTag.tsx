import { cn, discountPercent, formatPrice } from '../../utils/format'

interface PriceTagProps {
  price: number
  originalPrice: number
  size?: 'md' | 'lg'
}

export default function PriceTag({ price, originalPrice, size = 'md' }: PriceTagProps) {
  const off = discountPercent(price, originalPrice)
  return (
    <div className="flex flex-wrap items-baseline gap-x-2">
      <span className={cn('font-bold text-slate-900 dark:text-white', size === 'lg' ? 'text-3xl' : 'text-lg')}>
        {formatPrice(price)}
      </span>
      {off > 0 && (
        <>
          <span className={cn('text-slate-400 line-through', size === 'lg' ? 'text-base' : 'text-sm')}>
            {formatPrice(originalPrice)}
          </span>
          <span className={cn('font-semibold text-emerald-600 dark:text-emerald-400', size === 'lg' ? 'text-base' : 'text-xs')}>
            {off}% off
          </span>
        </>
      )}
    </div>
  )
}

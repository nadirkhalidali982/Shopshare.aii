import { useMemo } from 'react'
import type { Product } from '../../types'
import { similarProducts } from '../../utils/recommendations'
import ProductGrid from './ProductGrid'

interface SimilarProductsProps {
  product: Product
  products: Product[]
}

export default function SimilarProducts({ product, products }: SimilarProductsProps) {
  const similar = useMemo(() => similarProducts(product, products, 4), [product, products])
  if (similar.length === 0) return null
  return (
    <section aria-labelledby="similar-heading" className="mt-14">
      <h2 id="similar-heading" className="mb-5 text-2xl font-bold text-slate-900 dark:text-white">
        Similar products
      </h2>
      <ProductGrid products={similar} />
    </section>
  )
}

import { useState } from 'react'
import type { Category } from '../../types'
import { cn } from '../../utils/format'
import ProductImage from './ProductImage'

interface ProductGalleryProps {
  images: string[]
  name: string
  category: Category
}

export default function ProductGallery({ images, name, category }: ProductGalleryProps) {
  const [active, setActive] = useState(0)
  const current = images[Math.min(active, images.length - 1)]

  return (
    <div className="space-y-3">
      <div className="aspect-square overflow-hidden rounded-2xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-800">
        <ProductImage src={current} alt={name} category={category} className="h-full w-full object-cover" />
      </div>
      {images.length > 1 && (
        <div className="grid grid-cols-4 gap-3" role="tablist" aria-label="Product images">
          {images.map((src, i) => (
            <button
              key={src}
              type="button"
              role="tab"
              aria-selected={i === active}
              aria-label={`Show image ${i + 1} of ${images.length}`}
              onClick={() => setActive(i)}
              className={cn(
                'aspect-square overflow-hidden rounded-xl border-2 bg-slate-100 transition-colors dark:bg-slate-800',
                i === active ? 'border-brand-500' : 'border-transparent hover:border-slate-300 dark:hover:border-slate-600',
              )}
            >
              <ProductImage src={src} alt={`${name} view ${i + 1}`} category={category} className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

import type { User } from '../types'
import { uid } from '../utils/format'
import { delay } from './delay'

/*
 * MOCK AUTH - for demo only.
 * Users live in this browser's localStorage and passwords are NOT encrypted.
 * Replace with a real backend (hashed passwords, tokens) before production.
 */

interface StoredUser extends User {
  password: string
}

const USERS_KEY = 'shopsphere-users'

const DEMO_USER: StoredUser = {
  id: 'u_demo',
  name: 'Demo Shopper',
  email: 'demo@shopsphere.ai',
  password: 'Demo@123',
}

function readUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY)
    const list = raw ? (JSON.parse(raw) as StoredUser[]) : []
    return [DEMO_USER, ...list.filter((u) => u.id !== DEMO_USER.id)]
  } catch {
    return [DEMO_USER]
  }
}

function writeUsers(users: StoredUser[]): void {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users.filter((u) => u.id !== DEMO_USER.id)))
  } catch {
    // Storage full or blocked - nothing else we can do in a mock.
  }
}

function toPublic(user: StoredUser): User {
  const { password: _password, ...rest } = user
  void _password
  return rest
}

export const DEMO_CREDENTIALS = { email: DEMO_USER.email, password: DEMO_USER.password }

export async function loginUser(email: string, password: string): Promise<User> {
  await delay(500)
  const user = readUsers().find((u) => u.email.toLowerCase() === email.trim().toLowerCase())
  if (!user || user.password !== password) {
    throw new Error('Incorrect email or password')
  }
  return toPublic(user)
}

export async function registerUser(name: string, email: string, password: string): Promise<User> {
  await delay(600)
  const users = readUsers()
  if (users.some((u) => u.email.toLowerCase() === email.trim().toLowerCase())) {
    throw new Error('An account with this email already exists')
  }
  const user: StoredUser = {
    id: uid('u'),
    name: name.trim(),
    email: email.trim().toLowerCase(),
    password,
  }
  writeUsers([...users, user])
  return toPublic(user)
}

export async function updateUserProfile(updated: User): Promise<User> {
  await delay(300)
  const users = readUsers()
  const next = users.map((u) => (u.id === updated.id ? { ...u, ...updated } : u))
  writeUsers(next)
  return updated
}

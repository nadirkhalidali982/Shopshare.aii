import type { Product } from '../types'
import { parseIntent, type ParsedIntent } from '../utils/assistantParser'
import { formatPrice } from '../utils/format'
import { searchProducts } from '../utils/search'
import { delay } from './delay'
import { getProducts } from './products'

/*
 * AI SHOPPING ASSISTANT (rule-based, runs fully in the browser, free).
 *
 * To upgrade to a real local LLM later (for example Ollama, open-source):
 * keep this function signature and replace the body of getAssistantReply()
 * with a fetch() to your Ollama server, then map the answer to AssistantReply.
 */

export interface AssistantReply {
  text: string
  productIds: string[]
  suggestions: string[]
}

const DEFAULT_SUGGESTIONS = ['Gifts under 1500', 'Best headphones', 'Trending now', 'Fitness picks']

export async function getAssistantReply(message: string): Promise<AssistantReply> {
  const products = await getProducts()
  await delay(550)
  return buildReply(message, products)
}

function describeBudget(intent: ParsedIntent): string {
  if (intent.budgetMax !== undefined && intent.budgetMin !== undefined) {
    return ` between ${formatPrice(intent.budgetMin)} and ${formatPrice(intent.budgetMax)}`
  }
  if (intent.budgetMax !== undefined) return ` under ${formatPrice(intent.budgetMax)}`
  if (intent.budgetMin !== undefined) return ` above ${formatPrice(intent.budgetMin)}`
  return ''
}

function findMatches(products: Product[], intent: ParsedIntent, useBudget: boolean): Product[] {
  let pool = products.filter((p) => p.stock > 0)
  if (useBudget) {
    if (intent.budgetMax !== undefined) pool = pool.filter((p) => p.price <= (intent.budgetMax as number))
    if (intent.budgetMin !== undefined) pool = pool.filter((p) => p.price >= (intent.budgetMin as number))
  }

  // Keep only words that mean something in this catalogue ("mom" in "gift for mom" does not).
  const known = intent.keywords.filter((k) => searchProducts(products, k, { deep: false }).length > 0)

  let list: Product[]
  if (intent.keywords.length > 0 && known.length === 0 && !intent.category && !intent.gift) {
    list = []
  } else if (known.length > 0) {
    // (No category fallback here: if the exact item is over budget we say so instead.)
    // Every known word must match, so "wireless headphones" never returns a smartwatch.
    const perWord = known.map((k) => searchProducts(pool, k, { deep: false }))
    const idsInAll = new Set(perWord[0].map((p) => p.id))
    perWord.slice(1).forEach((matches) => {
      const ids = new Set(matches.map((p) => p.id))
      idsInAll.forEach((id) => {
        if (!ids.has(id)) idsInAll.delete(id)
      })
    })
    list = perWord[0].filter((p) => idsInAll.has(p.id))
  } else if (intent.category) {
    list = pool.filter((p) => p.category === intent.category)
  } else if (intent.gift) {
    list = pool.filter((p) => p.tags.includes('gift'))
  } else {
    list = pool
  }

  const sorted = [...list]
  if (intent.sort === 'cheap') sorted.sort((a, b) => a.price - b.price)
  else if (intent.sort === 'premium') sorted.sort((a, b) => b.price - a.price)
  else if (intent.sort === 'rating' || intent.keywords.length === 0) {
    sorted.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount)
  }
  return sorted
}

/** Pure function - easy to unit test and easy to swap for an LLM later. */
export function buildReply(message: string, products: Product[]): AssistantReply {
  const intent = parseIntent(message)

  if (intent.kind === 'greeting') {
    return {
      text: "Hi! I'm your ShopSphere assistant. Tell me what you're looking for, your budget, or who you're shopping for, and I'll pick products for you.",
      productIds: [],
      suggestions: DEFAULT_SUGGESTIONS,
    }
  }
  if (intent.kind === 'thanks') {
    return {
      text: "You're welcome! Want me to find anything else?",
      productIds: [],
      suggestions: DEFAULT_SUGGESTIONS,
    }
  }
  if (intent.kind === 'help') {
    return {
      text: 'I can find products by budget, category or occasion. Try "wireless headphones under 3000", "gift for mom under 1500" or "best rated yoga mat".',
      productIds: [],
      suggestions: DEFAULT_SUGGESTIONS,
    }
  }
  if (intent.kind === 'trending') {
    const trending = products
      .filter((p) => p.isTrending && p.stock > 0)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 4)
    return {
      text: 'These are trending with shoppers right now:',
      productIds: trending.map((p) => p.id),
      suggestions: ['Gifts under 1500', 'Best rated books', 'Cheap fitness picks'],
    }
  }

  const hasSubject =
    intent.keywords.length > 0 ||
    intent.category !== undefined ||
    intent.gift ||
    intent.budgetMax !== undefined ||
    intent.budgetMin !== undefined
  if (!hasSubject) {
    return {
      text: 'Tell me a bit more - what are you shopping for, and what is your budget? For example: "running shoes under 3000".',
      productIds: [],
      suggestions: DEFAULT_SUGGESTIONS,
    }
  }

  const matches = findMatches(products, intent, true)
  const budget = describeBudget(intent)
  const topic = intent.keywords.length > 0 ? intent.keywords.join(' ') : intent.category?.toLowerCase() ?? (intent.gift ? 'gift ideas' : 'picks')
  const adjective = intent.sort === 'rating' ? 'top-rated ' : intent.sort === 'cheap' ? 'budget-friendly ' : intent.sort === 'premium' ? 'premium ' : ''

  if (matches.length > 0) {
    const shown = matches.slice(0, 4)
    return {
      text: `Here ${shown.length === 1 ? 'is the best match' : `are ${shown.length} ${adjective}options`} for ${topic}${budget}:`,
      productIds: shown.map((p) => p.id),
      suggestions: intent.category
        ? [`Cheapest ${intent.category.toLowerCase()}`, `Best rated ${intent.category.toLowerCase()}`, 'Trending now']
        : DEFAULT_SUGGESTIONS,
    }
  }

  // Nothing within the budget - show the closest options instead of a dead end.
  if (intent.budgetMax !== undefined || intent.budgetMin !== undefined) {
    const relaxed = findMatches(products, intent, false)
      .sort((a, b) => a.price - b.price)
      .slice(0, 3)
    if (relaxed.length > 0) {
      return {
        text: `I couldn't find ${topic}${budget}, but these are the closest options:`,
        productIds: relaxed.map((p) => p.id),
        suggestions: DEFAULT_SUGGESTIONS,
      }
    }
  }

  return {
    text: `I couldn't find a good match for "${message.trim()}". Try a category like electronics, fashion, beauty, sports or books.`,
    productIds: [],
    suggestions: DEFAULT_SUGGESTIONS,
  }
}

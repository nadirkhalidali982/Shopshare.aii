import type { Address, CartLine, Order, OrderStatus, PaymentDraft, User } from '../types'
import type { Totals } from '../utils/pricing'
import { delay } from './delay'

export function describePayment(payment: PaymentDraft): string {
  if (payment.method === 'card') {
    const last4 = payment.cardNumber.replace(/\D/g, '').slice(-4)
    return `Card ending ${last4}`
  }
  if (payment.method === 'upi') return `UPI (${payment.upiId.trim()})`
  return 'Cash on Delivery'
}

interface PlaceOrderInput {
  user: User
  lines: CartLine[]
  address: Address
  payment: PaymentDraft
  totals: Totals
  promoCode: string | null
}

/** MOCK: no payment is processed. Card details are never stored. */
export async function placeOrder(input: PlaceOrderInput): Promise<Order> {
  await delay(900)
  const { user, lines, address, payment, totals, promoCode } = input
  return {
    id: `SS${Date.now().toString().slice(-8)}${Math.floor(Math.random() * 90 + 10)}`,
    userId: user.id,
    items: lines.map((l) => ({
      productId: l.product.id,
      name: l.product.name,
      image: l.product.images[0],
      price: l.product.price,
      quantity: l.quantity,
    })),
    address,
    paymentMethod: payment.method,
    paymentLabel: describePayment(payment),
    subtotal: totals.subtotal,
    discount: totals.discount,
    shipping: totals.shipping,
    gstIncluded: totals.gstIncluded,
    total: totals.total,
    promoCode,
    createdAt: new Date().toISOString(),
  }
}

export const ORDER_STEPS: OrderStatus[] = ['Placed', 'Packed', 'Shipped', 'Delivered']

/** Demo only: pretend the order moves forward as time passes. */
export function deriveOrderStatus(createdAt: string): OrderStatus {
  const minutes = (Date.now() - new Date(createdAt).getTime()) / 60_000
  if (minutes < 2) return 'Placed'
  if (minutes < 10) return 'Packed'
  if (minutes < 60) return 'Shipped'
  return 'Delivered'
}

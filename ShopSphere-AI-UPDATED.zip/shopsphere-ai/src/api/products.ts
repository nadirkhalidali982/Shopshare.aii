import { products } from '../data/products'
import { reviewsFor } from '../data/reviews'
import type { Product, Review } from '../types'
import { delay } from './delay'

/*
 * MOCK API. When a real backend is ready, replace the bodies of these
 * functions with fetch() calls - nothing else in the app needs to change.
 */

export async function getProducts(): Promise<Product[]> {
  await delay(350)
  return products
}

export async function getProductById(id: string): Promise<Product | null> {
  await delay(200)
  return products.find((p) => p.id === id) ?? null
}

export async function getReviews(productId: string): Promise<Review[]> {
  await delay(250)
  return reviewsFor(productId)
}

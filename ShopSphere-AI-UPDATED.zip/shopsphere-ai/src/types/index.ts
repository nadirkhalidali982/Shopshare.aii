export type Category =
  | 'Electronics'
  | 'Fashion'
  | 'Home & Kitchen'
  | 'Beauty'
  | 'Sports'
  | 'Books'
  | 'Accessories & Lifestyle'

export interface Product {
  id: string
  name: string
  brand: string
  category: Category
  price: number
  originalPrice: number
  rating: number
  reviewCount: number
  stock: number
  tags: string[]
  colors: string[]
  description: string
  images: string[]
  createdAt: string
  isTrending: boolean
}

export interface Review {
  id: string
  productId: string
  author: string
  rating: number
  title: string
  comment: string
  date: string
}

export interface CartItem {
  productId: string
  quantity: number
}

export interface CartLine {
  product: Product
  quantity: number
}

export interface Address {
  fullName: string
  phone: string
  line1: string
  city: string
  state: string
  pincode: string
}

export interface User {
  id: string
  name: string
  email: string
  phone?: string
  address?: Address
}

export type PaymentMethod = 'card' | 'upi' | 'cod'

/** Raw payment form values. Never persisted (we do not store card data). */
export interface PaymentDraft {
  method: PaymentMethod
  cardNumber: string
  cardName: string
  expiry: string
  cvv: string
  upiId: string
}

export type OrderStatus = 'Placed' | 'Packed' | 'Shipped' | 'Delivered'

export interface OrderItem {
  productId: string
  name: string
  image: string
  price: number
  quantity: number
}

export interface Order {
  id: string
  userId: string
  items: OrderItem[]
  address: Address
  paymentMethod: PaymentMethod
  /** Safe, display-only description such as "Visa ending 4242" */
  paymentLabel: string
  subtotal: number
  discount: number
  shipping: number
  gstIncluded: number
  total: number
  promoCode: string | null
  createdAt: string
}

export type BehaviorAction = 'view' | 'cart' | 'wishlist' | 'purchase'

export interface BehaviorEvent {
  productId: string
  action: BehaviorAction
  at: number
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  text: string
  productIds?: string[]
  suggestions?: string[]
  createdAt: number
}

export type SortKey =
  | 'relevance'
  | 'price-asc'
  | 'price-desc'
  | 'rating'
  | 'newest'

import type { Category } from '../types'

export type IntentKind = 'greeting' | 'thanks' | 'help' | 'trending' | 'search'
export type SortPreference = 'relevance' | 'rating' | 'cheap' | 'premium'

export interface ParsedIntent {
  kind: IntentKind
  budgetMax?: number
  budgetMin?: number
  category?: Category
  /** Words left after removing filler, budget and number words */
  keywords: string[]
  gift: boolean
  sort: SortPreference
}

const STOPWORDS = new Set([
  'i', 'me', 'my', 'we', 'us', 'you', 'it', 'a', 'an', 'the', 'for', 'to', 'of', 'and', 'or', 'in', 'on',
  'with', 'by', 'from', 'at', 'is', 'are', 'can', 'do', 'does', 'have', 'has', 'what', 'which', 'that',
  'this', 'some', 'any', 'one', 'ones', 'please', 'pls', 'bro', 'yaar', 'sir', 'hi', 'hello', 'hey',
  'want', 'need', 'looking', 'look', 'show', 'find', 'get', 'give', 'suggest', 'recommend', 'buy',
  'something', 'good', 'best', 'top', 'nice', 'great', 'new', 'quality', 'high', 'rated', 'rating',
  'cheap', 'cheapest', 'affordable', 'premium', 'expensive', 'luxury', 'budget', 'under', 'below',
  'above', 'over', 'within', 'than', 'less', 'more', 'least', 'max', 'maximum', 'min', 'minimum',
  'upto', 'up', 'around', 'about', 'not', 'rs', 'inr', 'rupees', 'rupee', 'k', 'thousand', 'hazar',
  'gift', 'gifts', 'present', 'ideas', 'idea', 'birthday', 'anniversary', 'wedding', 'diwali',
  'festival', 'festive', 'products', 'product', 'items', 'item', 'options', 'option', 'trending',
  'popular', 'now', 'today', 'right', 'sasta', 'starting', 'between', 'ones', 'cheaper', 'show',
])

const CATEGORY_WORDS: Record<Category, string[]> = {
  Electronics: [
    'electronics', 'electronic', 'gadget', 'gadgets', 'tech', 'phone', 'phones', 'mobile', 'smartphone',
    'headphone', 'headphones', 'earphone', 'earphones', 'earbuds', 'watch', 'smartwatch', 'charger',
    'powerbank', 'laptop',
  ],
  Fashion: [
    'fashion', 'clothes', 'clothing', 'wear', 'shoe', 'shoes', 'sneaker', 'sneakers', 'jacket', 'tshirt',
    'shirt', 'bag', 'bags', 'dress', 'footwear',
  ],
  'Home & Kitchen': [
    'home', 'kitchen', 'cookware', 'kettle', 'bedsheet', 'bedding', 'lamp', 'decor', 'appliance',
  ],
  Beauty: ['beauty', 'skincare', 'skin', 'face', 'hair', 'lipstick', 'makeup', 'serum', 'facewash'],
  Sports: [
    'sport', 'sports', 'gym', 'yoga', 'fitness', 'cricket', 'workout', 'dumbbell', 'dumbbells', 'exercise',
  ],
  Books: ['book', 'books', 'novel', 'novels', 'reading', 'story', 'stories'],
}

const NUMBER_WORD = '(\\d[\\d,]*(?:\\.\\d+)?)\\s*(k|thousand|hazar)?'
const MAX_RE = new RegExp(
  `(?:under|below|less than|within|upto|up to|max(?:imum)?|budget(?: of)?|around|not more than)\\s*(?:rs\\.?|₹|inr)?\\s*${NUMBER_WORD}`,
  'i',
)
const MIN_RE = new RegExp(
  `(?:above|over|more than|at least|minimum|min|starting(?: from)?)\\s*(?:rs\\.?|₹|inr)?\\s*${NUMBER_WORD}`,
  'i',
)
const BARE_RE = new RegExp(`(?:rs\\.?|₹|inr)\\s*${NUMBER_WORD}`, 'i')
const BETWEEN_RE = new RegExp(
  `between\\s*(?:rs\\.?|₹|inr)?\\s*${NUMBER_WORD}\\s*(?:and|to|-)\\s*(?:rs\\.?|₹|inr)?\\s*${NUMBER_WORD}`,
  'i',
)

function toNumber(raw: string, suffix?: string): number {
  let n = parseFloat(raw.replace(/,/g, ''))
  if (suffix && /^(k|thousand|hazar)$/i.test(suffix)) n *= 1000
  return n
}

export function parseIntent(message: string): ParsedIntent {
  const text = message.toLowerCase().trim()

  let budgetMax: number | undefined
  let budgetMin: number | undefined
  const betweenMatch = BETWEEN_RE.exec(text)
  if (betweenMatch) {
    // "between 500 and 2k": a bare first number borrows the "k" of the second.
    const firstSuffix = betweenMatch[2] ?? (Number(betweenMatch[1].replace(/,/g, '')) < 100 ? betweenMatch[4] : undefined)
    const a = toNumber(betweenMatch[1], firstSuffix)
    const b = toNumber(betweenMatch[3], betweenMatch[4])
    budgetMin = Math.min(a, b)
    budgetMax = Math.max(a, b)
  }
  const maxMatch = betweenMatch ? null : MAX_RE.exec(text)
  const minMatch = betweenMatch ? null : MIN_RE.exec(text)
  if (maxMatch) budgetMax = toNumber(maxMatch[1], maxMatch[2])
  if (minMatch) budgetMin = toNumber(minMatch[1], minMatch[2])
  if (budgetMax === undefined && budgetMin === undefined) {
    const bare = BARE_RE.exec(text)
    if (bare) budgetMax = toNumber(bare[1], bare[2])
  }

  const tokens = text.replace(/[^a-z0-9\s-]/g, ' ').split(/[\s-]+/).filter(Boolean)

  const tokenSet = new Set(tokens)
  let category: Category | undefined
  let bestHits = 0
  ;(Object.keys(CATEGORY_WORDS) as Category[]).forEach((cat) => {
    const hits = CATEGORY_WORDS[cat].filter((w) => tokenSet.has(w)).length
    if (hits > bestHits) {
      bestHits = hits
      category = cat
    }
  })

  const keywords = tokens.filter((t) => !STOPWORDS.has(t) && !/^\d/.test(t) && t.length > 1)
  const gift = /\b(gift|gifts|present|birthday|anniversary|wedding|diwali|festival|festive|raksha)\b/.test(text)

  let sort: SortPreference = 'relevance'
  if (/\b(cheap|cheapest|affordable|lowest|low price|sasta)\b/.test(text)) sort = 'cheap'
  else if (/\b(premium|luxury|expensive|high end)\b/.test(text)) sort = 'premium'
  else if (/\b(best|top rated|highest rated|top)\b/.test(text)) sort = 'rating'

  let kind: IntentKind = 'search'
  const hasSubject = keywords.length > 0 || category !== undefined || gift || budgetMax !== undefined || budgetMin !== undefined
  if (/\b(thanks|thank you|thx|shukriya|dhanyavaad)\b/.test(text)) kind = 'thanks'
  else if (/\b(help|what can you do|how do you work|who are you)\b/.test(text)) kind = 'help'
  else if (/^(hi+|hello+|hey+|namaste|good (morning|evening|afternoon))\b/.test(text) && !hasSubject) kind = 'greeting'
  else if (/\b(trending|popular|bestsell\w*|best sell\w*|hot right now)\b/.test(text) && keywords.length === 0 && !category)
    kind = 'trending'

  return { kind, budgetMax, budgetMin, category, keywords, gift, sort }
}

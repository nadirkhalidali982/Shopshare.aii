import type { CartLine } from '../types'

export const FREE_SHIPPING_THRESHOLD = 999
export const SHIPPING_FEE = 79
/** Indian retail prices already include GST, so we only show it as info. */
export const GST_RATE = 0.18

export interface PromoInfo {
  code: string
  label: string
  type: 'percent' | 'freeship'
  value?: number
}

export const PROMO_CODES: Record<string, PromoInfo> = {
  WELCOME10: { code: 'WELCOME10', label: '10% off your order', type: 'percent', value: 10 },
  FREESHIP: { code: 'FREESHIP', label: 'Free shipping', type: 'freeship' },
}

export function findPromo(code: string): PromoInfo | null {
  return PROMO_CODES[code.trim().toUpperCase()] ?? null
}

export interface Totals {
  itemCount: number
  subtotal: number
  discount: number
  shipping: number
  /** GST already included inside the item prices (display only) */
  gstIncluded: number
  total: number
  /** Total saved compared to MRP, excluding the promo */
  mrpSavings: number
  amountToFreeShipping: number
}

export function computeTotals(lines: CartLine[], promoCode: string | null): Totals {
  const promo = promoCode ? findPromo(promoCode) : null
  const itemCount = lines.reduce((n, l) => n + l.quantity, 0)
  const subtotal = lines.reduce((sum, l) => sum + l.product.price * l.quantity, 0)
  const mrpSavings = lines.reduce(
    (sum, l) => sum + Math.max(0, l.product.originalPrice - l.product.price) * l.quantity,
    0,
  )
  const discount =
    promo && promo.type === 'percent' ? Math.round((subtotal * (promo.value ?? 0)) / 100) : 0
  const net = subtotal - discount
  const freeShipping = promo?.type === 'freeship' || net >= FREE_SHIPPING_THRESHOLD
  const shipping = itemCount === 0 || freeShipping ? 0 : SHIPPING_FEE
  const gstIncluded = Math.round((net * GST_RATE) / (1 + GST_RATE))
  return {
    itemCount,
    subtotal,
    discount,
    shipping,
    gstIncluded,
    total: net + shipping,
    mrpSavings,
    amountToFreeShipping: freeShipping ? 0 : Math.max(0, FREE_SHIPPING_THRESHOLD - net),
  }
}

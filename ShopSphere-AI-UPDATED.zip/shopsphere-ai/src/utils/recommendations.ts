import type { BehaviorAction, BehaviorEvent, Product } from '../types'

/** How strongly each action says "I like this kind of product". */
export const ACTION_WEIGHT: Record<BehaviorAction, number> = {
  view: 1,
  wishlist: 2,
  cart: 3,
  purchase: 4,
}

export interface InterestProfile {
  /** Category -> interest, normalised to 0..1 */
  categories: Record<string, number>
  /** Tag -> interest, normalised to 0..1 */
  tags: Record<string, number>
  /** Product id -> best action the user took on it, with total weight */
  touched: Record<string, { weight: number; action: BehaviorAction }>
  /** 0 means a brand new user (cold start) */
  total: number
}

export interface RecommendationContext {
  events: BehaviorEvent[]
  cartIds: string[]
  wishlistIds: string[]
  purchasedIds: string[]
}

export interface Recommendation {
  product: Product
  score: number
  reason: string
}

function normalise(map: Record<string, number>): Record<string, number> {
  const max = Math.max(0, ...Object.values(map))
  if (max === 0) return {}
  const out: Record<string, number> = {}
  Object.entries(map).forEach(([k, v]) => {
    out[k] = v / max
  })
  return out
}

/**
 * Turn raw behaviour (views, cart adds, wishlist, purchases) into a weighted
 * interest profile over categories and tags.
 */
export function buildInterestProfile(
  products: Product[],
  ctx: RecommendationContext,
): InterestProfile {
  const byId = new Map(products.map((p) => [p.id, p]))
  const categories: Record<string, number> = {}
  const tags: Record<string, number> = {}
  const touched: InterestProfile['touched'] = {}
  let total = 0

  const apply = (productId: string, action: BehaviorAction) => {
    const product = byId.get(productId)
    if (!product) return
    const weight = ACTION_WEIGHT[action]
    categories[product.category] = (categories[product.category] ?? 0) + weight
    product.tags.forEach((t) => {
      tags[t] = (tags[t] ?? 0) + weight
    })
    const prev = touched[productId]
    touched[productId] = {
      weight: (prev?.weight ?? 0) + weight,
      action: !prev || ACTION_WEIGHT[action] > ACTION_WEIGHT[prev.action] ? action : prev.action,
    }
    total += weight
  }

  ctx.events.forEach((e) => apply(e.productId, e.action))
  // Current state also counts, in case events were cleared but the cart/wishlist remain.
  ctx.cartIds.forEach((id) => {
    if (!touched[id] || ACTION_WEIGHT[touched[id].action] < ACTION_WEIGHT.cart) apply(id, 'cart')
  })
  ctx.wishlistIds.forEach((id) => {
    if (!touched[id]) apply(id, 'wishlist')
  })
  ctx.purchasedIds.forEach((id) => {
    if (!touched[id] || ACTION_WEIGHT[touched[id].action] < ACTION_WEIGHT.purchase) apply(id, 'purchase')
  })

  return { categories: normalise(categories), tags: normalise(tags), touched, total }
}

function jaccard(a: string[], b: string[]): number {
  if (a.length === 0 || b.length === 0) return 0
  const setA = new Set(a)
  const setB = new Set(b)
  let intersection = 0
  setA.forEach((x) => {
    if (setB.has(x)) intersection += 1
  })
  return intersection / (setA.size + setB.size - intersection)
}

/** 0..1 similarity from shared tags (60%) and same category (40%). */
export function similarity(a: Product, b: Product): number {
  return 0.6 * jaccard(a.tags, b.tags) + (a.category === b.category ? 0.4 : 0)
}

export function similarProducts(product: Product, products: Product[], limit = 4): Product[] {
  return products
    .filter((p) => p.id !== product.id)
    .map((p) => ({ p, s: similarity(product, p) }))
    .filter((x) => x.s > 0)
    .sort((x, y) => y.s - x.s || y.p.rating - x.p.rating)
    .slice(0, limit)
    .map((x) => x.p)
}

function popularity(p: Product): number {
  return p.rating * Math.log10(p.reviewCount + 10)
}

/** Trending / top rated fallback used for brand-new users. */
export function coldStartPicks(products: Product[], limit: number): Recommendation[] {
  return [...products]
    .filter((p) => p.stock > 0)
    .sort((a, b) => Number(b.isTrending) - Number(a.isTrending) || popularity(b) - popularity(a))
    .slice(0, limit)
    .map((product) => ({
      product,
      score: popularity(product),
      reason: product.isTrending ? 'Trending right now' : 'Top rated by shoppers',
    }))
}

function reasonText(action: BehaviorAction, name: string): string {
  switch (action) {
    case 'purchase':
      return `Because you bought ${name}`
    case 'cart':
      return `Because you added ${name} to your cart`
    case 'wishlist':
      return `Because you saved ${name}`
    default:
      return `Because you viewed ${name}`
  }
}

/**
 * Rank the catalogue for this user.
 * score = category interest + tag interest + quality boost - penalties
 */
export function recommend(
  products: Product[],
  ctx: RecommendationContext,
  limit = 8,
): Recommendation[] {
  const profile = buildInterestProfile(products, ctx)
  if (profile.total === 0) return coldStartPicks(products, limit)

  const byId = new Map(products.map((p) => [p.id, p]))
  const purchased = new Set(ctx.purchasedIds)
  const inCart = new Set(ctx.cartIds)
  const touchedProducts = Object.entries(profile.touched)
    .map(([id, info]) => ({ product: byId.get(id), ...info }))
    .filter((x): x is { product: Product; weight: number; action: BehaviorAction } => Boolean(x.product))

  const scored = products.map((product) => {
    const categoryScore = profile.categories[product.category] ?? 0
    const tagScore =
      product.tags.reduce((sum, t) => sum + (profile.tags[t] ?? 0), 0) / Math.max(1, product.tags.length)
    const quality = (product.rating - 3) * 0.5 + Math.log10(product.reviewCount + 1) * 0.3
    let score = 4 * categoryScore + 3 * tagScore + quality + (product.isTrending ? 0.3 : 0)
    if (purchased.has(product.id)) score -= 3
    if (inCart.has(product.id)) score -= 2
    if (product.stock === 0) score -= 5

    // Explain the pick using the most relevant thing the user did.
    let reason = product.isTrending ? 'Trending in your interests' : 'Matches your interests'
    let best = 0
    touchedProducts.forEach((t) => {
      if (t.product.id === product.id) return
      const strength = similarity(t.product, product) * t.weight
      if (strength > best) {
        best = strength
        reason = reasonText(t.action, t.product.name)
      }
    })
    return { product, score, reason }
  })

  return scored.sort((a, b) => b.score - a.score).slice(0, limit)
}

import Fuse from 'fuse.js'
import type { Product } from '../types'

interface ProductIndexes {
  /** Name, tags, category, brand - precise, used first. */
  primary: Fuse<Product>
  /** Also looks inside descriptions - used only when the precise search finds nothing. */
  deep: Fuse<Product>
}

const indexCache = new WeakMap<Product[], ProductIndexes>()

function getIndexes(products: Product[]): ProductIndexes {
  let indexes = indexCache.get(products)
  if (!indexes) {
    const base = [
      { name: 'name', weight: 0.4 },
      { name: 'tags', weight: 0.3 },
      { name: 'category', weight: 0.15 },
      { name: 'brand', weight: 0.15 },
    ]
    const common = { ignoreLocation: true, minMatchCharLength: 2, includeScore: true }
    indexes = {
      primary: new Fuse(products, { ...common, keys: base, threshold: 0.28 }),
      deep: new Fuse(products, {
        ...common,
        keys: [...base, { name: 'description', weight: 0.1 }],
        threshold: 0.3,
      }),
    }
    indexCache.set(products, indexes)
  }
  return indexes
}

/**
 * Typo-tolerant search. "shos" still finds "shoes".
 * Results are ordered best match first.
 */
export function searchProducts(
  products: Product[],
  query: string,
  options: { deep?: boolean } = {},
): Product[] {
  const q = query.trim()
  if (!q) return products
  const { primary, deep } = getIndexes(products)
  const precise = primary.search(q)
  if (precise.length > 0 || options.deep === false) return precise.map((r) => r.item)
  return deep.search(q).map((r) => r.item)
}

interface VocabEntry {
  word: string
}

const vocabCache = new WeakMap<Product[], { words: Set<string>; fuse: Fuse<VocabEntry> }>()

function getVocab(products: Product[]) {
  let vocab = vocabCache.get(products)
  if (!vocab) {
    const words = new Set<string>()
    products.forEach((p) => {
      const text = [p.name, p.brand, p.category, ...p.tags].join(' ').toLowerCase()
      text
        .split(/[^a-z0-9]+/)
        .filter((w) => w.length >= 3)
        .forEach((w) => words.add(w))
    })
    const entries: VocabEntry[] = Array.from(words).map((word) => ({ word }))
    vocab = {
      words,
      fuse: new Fuse(entries, { keys: ['word'], threshold: 0.4, includeScore: true }),
    }
    vocabCache.set(products, vocab)
  }
  return vocab
}

/**
 * "Did you mean...?" - fixes each unknown word using the catalogue vocabulary.
 * Returns null if nothing could be improved.
 */
export function didYouMean(products: Product[], query: string): string | null {
  const vocab = getVocab(products)
  const tokens = query.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean)
  if (tokens.length === 0) return null
  let changed = false
  const fixed = tokens.map((token) => {
    if (token.length < 3 || vocab.words.has(token)) return token
    const best = vocab.fuse.search(token, { limit: 1 })[0]
    if (best) {
      changed = true
      return best.item.word
    }
    return token
  })
  return changed ? fixed.join(' ') : null
}

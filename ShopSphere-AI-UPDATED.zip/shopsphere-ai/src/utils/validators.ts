import type { Address, PaymentDraft } from '../types'

export type AddressErrors = Partial<Record<keyof Address, string>>
export type PaymentErrors = Partial<Record<keyof PaymentDraft, string>>

export function validateEmail(email: string): string | null {
  if (!email.trim()) return 'Email is required'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) return 'Enter a valid email address'
  return null
}

export function validatePassword(password: string): string | null {
  if (!password) return 'Password is required'
  if (password.length < 6) return 'Password must be at least 6 characters'
  return null
}

export function validateName(name: string): string | null {
  if (!name.trim()) return 'Name is required'
  if (name.trim().length < 2) return 'Name is too short'
  return null
}

export function validatePhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, '')
  if (!digits) return 'Phone number is required'
  if (!/^[6-9]\d{9}$/.test(digits)) return 'Enter a valid 10-digit mobile number'
  return null
}

export function validatePincode(pincode: string): string | null {
  if (!pincode.trim()) return 'PIN code is required'
  if (!/^[1-9]\d{5}$/.test(pincode.trim())) return 'Enter a valid 6-digit PIN code'
  return null
}

/** Luhn checksum used by real card numbers. */
export function isLuhnValid(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '')
  if (digits.length < 13 || digits.length > 19) return false
  let sum = 0
  let double = false
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let d = Number(digits[i])
    if (double) {
      d *= 2
      if (d > 9) d -= 9
    }
    sum += d
    double = !double
  }
  return sum % 10 === 0
}

export function validateExpiry(expiry: string): string | null {
  const match = /^(\d{2})\/(\d{2})$/.exec(expiry.trim())
  if (!match) return 'Use MM/YY format'
  const month = Number(match[1])
  const year = 2000 + Number(match[2])
  if (month < 1 || month > 12) return 'Invalid month'
  const now = new Date()
  const endOfMonth = new Date(year, month, 0, 23, 59, 59)
  if (endOfMonth < now) return 'Card has expired'
  return null
}

export function validateUpi(upiId: string): string | null {
  if (!upiId.trim()) return 'UPI ID is required'
  if (!/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(upiId.trim())) return 'Enter a valid UPI ID (e.g. name@bank)'
  return null
}

export function validateAddress(address: Address): AddressErrors {
  const errors: AddressErrors = {}
  const name = validateName(address.fullName)
  if (name) errors.fullName = name
  const phone = validatePhone(address.phone)
  if (phone) errors.phone = phone
  if (!address.line1.trim() || address.line1.trim().length < 5) {
    errors.line1 = 'Enter your full address (house no, street, area)'
  }
  if (!address.city.trim()) errors.city = 'City is required'
  if (!address.state) errors.state = 'Select a state'
  const pin = validatePincode(address.pincode)
  if (pin) errors.pincode = pin
  return errors
}

export function validatePayment(payment: PaymentDraft): PaymentErrors {
  const errors: PaymentErrors = {}
  if (payment.method === 'card') {
    if (!isLuhnValid(payment.cardNumber)) errors.cardNumber = 'Enter a valid card number'
    if (!payment.cardName.trim()) errors.cardName = 'Name on card is required'
    const expiry = validateExpiry(payment.expiry)
    if (expiry) errors.expiry = expiry
    if (!/^\d{3,4}$/.test(payment.cvv)) errors.cvv = 'Enter a 3 or 4 digit CVV'
  }
  if (payment.method === 'upi') {
    const upi = validateUpi(payment.upiId)
    if (upi) errors.upiId = upi
  }
  return errors
}

export function hasErrors(errors: object): boolean {
  return Object.keys(errors).length > 0
}

export const emptyAddress: Address = {
  fullName: '',
  phone: '',
  line1: '',
  city: '',
  state: '',
  pincode: '',
}

export const emptyPayment: PaymentDraft = {
  method: 'cod',
  cardNumber: '',
  cardName: '',
  expiry: '',
  cvv: '',
  upiId: '',
}

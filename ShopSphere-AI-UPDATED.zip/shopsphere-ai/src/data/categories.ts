import type { Category } from '../types'

export interface CategoryInfo {
  name: Category
  emoji: string
  tagline: string
  gradient: string
}

export const categories: CategoryInfo[] = [
  { name: 'Electronics', emoji: '🎧', tagline: 'Gadgets & gear', gradient: 'from-sky-500 to-indigo-600' },
  { name: 'Fashion', emoji: '👟', tagline: 'Look sharp daily', gradient: 'from-rose-500 to-orange-500' },
  { name: 'Home & Kitchen', emoji: '🍳', tagline: 'Make home better', gradient: 'from-amber-500 to-red-500' },
  { name: 'Beauty', emoji: '💄', tagline: 'Glow up essentials', gradient: 'from-fuchsia-500 to-pink-600' },
  { name: 'Sports', emoji: '🏏', tagline: 'Train. Play. Win.', gradient: 'from-emerald-500 to-teal-600' },
  { name: 'Books', emoji: '📚', tagline: 'Stories & skills', gradient: 'from-violet-500 to-purple-700' },
  { name: 'Accessories & Lifestyle', emoji: '👜', tagline: 'Everyday essentials', gradient: 'from-amber-500 to-rose-600' },
]

export const categoryNames: Category[] = categories.map((c) => c.name)

export function categoryEmoji(category: Category): string {
  return categories.find((c) => c.name === category)?.emoji ?? '🛍️'
}

export function categoryGradient(category: Category): string {
  return categories.find((c) => c.name === category)?.gradient ?? 'from-slate-500 to-slate-700'
}

import type { Review } from '../types'

interface ReviewTemplate {
  author: string
  rating: number
  title: string
  comment: string
  daysAgo: number
}

const pool: ReviewTemplate[] = [
  {
    author: 'Aarav S.',
    rating: 5,
    title: 'Worth every rupee',
    comment: 'Quality is far better than I expected at this price. Packaging was neat and delivery was quick.',
    daysAgo: 6,
  },
  {
    author: 'Priya M.',
    rating: 4,
    title: 'Really good, small nitpicks',
    comment: 'Works exactly as described. Only wish the box included a bit more documentation, but I am happy overall.',
    daysAgo: 14,
  },
  {
    author: 'Rohan K.',
    rating: 5,
    title: 'Bought it as a gift',
    comment: 'Gifted this to my brother and he loved it. Looks premium and feels solid.',
    daysAgo: 21,
  },
  {
    author: 'Sneha R.',
    rating: 4,
    title: 'Good value',
    comment: 'Good build and finish. I have been using it daily for a month with no issues so far.',
    daysAgo: 30,
  },
  {
    author: 'Imran A.',
    rating: 3,
    title: 'Decent, not perfect',
    comment: 'It does the job. Colour was slightly different from the photos, but nothing major.',
    daysAgo: 38,
  },
  {
    author: 'Kavya N.',
    rating: 5,
    title: 'Highly recommended',
    comment: 'Exceeded my expectations. Already ordered another one for my family.',
    daysAgo: 45,
  },
  {
    author: 'Vikram T.',
    rating: 4,
    title: 'Solid purchase',
    comment: 'Delivery in two days and the product matched the listing. Customer support also replied fast.',
    daysAgo: 52,
  },
  {
    author: 'Neha P.',
    rating: 5,
    title: 'Love it',
    comment: 'Very happy with this. Great quality for the money and it looks even better in person.',
    daysAgo: 60,
  },
]

function hash(text: string): number {
  let h = 0
  for (let i = 0; i < text.length; i += 1) {
    h = (h * 31 + text.charCodeAt(i)) % 100000
  }
  return h
}

/** Deterministic mock reviews: the same product always shows the same reviews. */
export function reviewsFor(productId: string): Review[] {
  const start = hash(productId) % pool.length
  const today = new Date('2026-10-10').getTime()
  return Array.from({ length: 4 }, (_, i) => {
    const t = pool[(start + i) % pool.length]
    return {
      id: `${productId}-r${i}`,
      productId,
      author: t.author,
      rating: t.rating,
      title: t.title,
      comment: t.comment,
      date: new Date(today - t.daysAgo * 86_400_000).toISOString(),
    }
  })
}

import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { Heart, ShoppingCart, Trash2 } from 'lucide-react'
import PriceTag from '../components/product/PriceTag'
import ProductImage from '../components/product/ProductImage'
import RatingStars from '../components/product/RatingStars'
import Button, { buttonStyles } from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { ProductGridSkeleton } from '../components/ui/Skeleton'
import { useProductActions } from '../hooks/useProductActions'
import { useProducts } from '../hooks/useProducts'
import { useUiStore } from '../store/uiStore'
import { useWishlistStore } from '../store/wishlistStore'
import type { Product } from '../types'

export default function Wishlist() {
  const { products, loading } = useProducts()
  const ids = useWishlistStore((s) => s.ids)
  const remove = useWishlistStore((s) => s.remove)
  const toast = useUiStore((s) => s.pushToast)
  const { addToCart } = useProductActions()

  const saved = useMemo(
    () => ids.map((id) => products.find((p) => p.id === id)).filter((p): p is Product => Boolean(p)),
    [ids, products],
  )

  if (loading && ids.length > 0) return <ProductGridSkeleton count={4} />

  const moveToCart = (product: Product) => {
    if (addToCart(product)) remove(product.id)
  }

  return (
    <div>
      <h1 className="mb-6 text-3xl font-extrabold text-slate-900 dark:text-white">
        My wishlist <span className="text-lg font-semibold text-slate-500">({saved.length})</span>
      </h1>
      {saved.length === 0 ? (
        <EmptyState
          icon={<Heart className="h-8 w-8" />}
          title="Your wishlist is empty"
          description="Tap the heart on any product to save it here for later."
          action={
            <Link to="/shop" className={buttonStyles()}>
              Explore products
            </Link>
          }
        />
      ) : (
        <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {saved.map((p) => (
            <li key={p.id} className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
              <Link to={`/product/${p.id}`} className="h-28 w-28 shrink-0 overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800" aria-label={`View ${p.name}`}>
                <ProductImage src={p.images[0]} alt={p.name} category={p.category} className="h-full w-full object-cover" />
              </Link>
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <Link to={`/product/${p.id}`} className="line-clamp-2 text-sm font-semibold text-slate-900 hover:text-brand-600 dark:text-white">
                  {p.name}
                </Link>
                <RatingStars rating={p.rating} />
                <PriceTag price={p.price} originalPrice={p.originalPrice} />
                <div className="mt-auto flex gap-2 pt-2">
                  <Button size="sm" className="flex-1" disabled={p.stock === 0} onClick={() => moveToCart(p)}>
                    <ShoppingCart className="h-4 w-4" aria-hidden="true" />
                    {p.stock === 0 ? 'Sold out' : 'Move to cart'}
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    aria-label={`Remove ${p.name} from wishlist`}
                    onClick={() => {
                      remove(p.id)
                      toast('Removed from wishlist', 'info')
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

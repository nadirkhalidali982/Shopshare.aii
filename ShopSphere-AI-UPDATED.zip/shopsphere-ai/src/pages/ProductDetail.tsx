import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Check, ChevronRight, Heart, Minus, Plus, RotateCcw, ShieldCheck, ShoppingCart, Truck } from 'lucide-react'
import { getReviews } from '../api/products'
import ProductGallery from '../components/product/ProductGallery'
import PriceTag from '../components/product/PriceTag'
import RatingStars from '../components/product/RatingStars'
import SimilarProducts from '../components/product/SimilarProducts'
import Badge from '../components/ui/Badge'
import Button, { buttonStyles } from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { Skeleton } from '../components/ui/Skeleton'
import { useProductActions } from '../hooks/useProductActions'
import { useProducts } from '../hooks/useProducts'
import { MAX_QTY } from '../store/cartStore'
import { useBehaviorStore } from '../store/userBehaviorStore'
import { useWishlistStore } from '../store/wishlistStore'
import type { Review } from '../types'
import { cn, formatDate } from '../utils/format'

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>()
  const { products, loading } = useProducts()
  const product = useMemo(() => products.find((p) => p.id === id), [products, id])
  const { addToCart, toggleWishlist } = useProductActions()
  const wished = useWishlistStore((s) => (id ? s.ids.includes(id) : false))
  const track = useBehaviorStore((s) => s.track)

  const [quantity, setQuantity] = useState(1)
  const [color, setColor] = useState<string | null>(null)
  const [reviews, setReviews] = useState<Review[] | null>(null)

  // Reset the form and record a "view" every time a different product opens.
  useEffect(() => {
    setQuantity(1)
    setColor(null)
    setReviews(null)
    window.scrollTo({ top: 0 })
  }, [id])

  useEffect(() => {
    if (product) track(product.id, 'view')
    // Track once per product id, not on every re-render of the product object.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product?.id])

  useEffect(() => {
    if (!id) return
    let active = true
    getReviews(id).then((r) => {
      if (active) setReviews(r)
    })
    return () => {
      active = false
    }
  }, [id])

  if (loading) {
    return (
      <div className="grid gap-10 lg:grid-cols-2" role="status" aria-label="Loading product">
        <Skeleton className="aspect-square w-full rounded-2xl" />
        <div className="space-y-4">
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-9 w-3/4" />
          <Skeleton className="h-5 w-1/3" />
          <Skeleton className="h-10 w-1/2" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <EmptyState
        title="Product not found"
        description="This product may have been removed or the link is incorrect."
        action={
          <Link to="/shop" className={buttonStyles()}>
            Back to shop
          </Link>
        }
      />
    )
  }

  const soldOut = product.stock === 0
  const maxQty = Math.min(MAX_QTY, product.stock)
  const lowStock = product.stock > 0 && product.stock <= 20
  const avg = reviews && reviews.length > 0 ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : null

  return (
    <div>
      <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
        <Link to="/" className="hover:text-brand-600">
          Home
        </Link>
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
        <Link to={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-brand-600">
          {product.category}
        </Link>
        <ChevronRight className="h-4 w-4" aria-hidden="true" />
        <span className="line-clamp-1 font-medium text-slate-700 dark:text-slate-200">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        <ProductGallery images={product.images} name={product.name} category={product.category} />

        <div>
          <p className="text-sm font-semibold uppercase tracking-wide text-brand-600 dark:text-brand-300">{product.brand}</p>
          <h1 className="mt-1 text-3xl font-extrabold leading-tight text-slate-900 dark:text-white">{product.name}</h1>

          <div className="mt-3 flex flex-wrap items-center gap-3">
            <RatingStars rating={product.rating} count={product.reviewCount} size="md" />
            {product.isTrending && <Badge tone="amber">Trending</Badge>}
          </div>

          <div className="mt-5">
            <PriceTag price={product.price} originalPrice={product.originalPrice} size="lg" />
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Inclusive of all taxes</p>
          </div>

          <p className="mt-5 leading-relaxed text-slate-600 dark:text-slate-300">{product.description}</p>

          {product.colors.length > 0 && (
            <fieldset className="mt-6">
              <legend className="mb-2 text-sm font-semibold text-slate-800 dark:text-slate-200">
                Colour{color ? `: ${color}` : ''}
              </legend>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    aria-pressed={color === c}
                    className={cn(
                      'rounded-xl border-2 px-4 py-2 text-sm font-medium transition-colors',
                      color === c
                        ? 'border-brand-500 bg-brand-50 text-brand-800 dark:bg-brand-900/30 dark:text-brand-200'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300 dark:border-slate-700 dark:text-slate-300',
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </fieldset>
          )}

          <div className="mt-6">
            {soldOut ? (
              <Badge tone="red">Out of stock</Badge>
            ) : lowStock ? (
              <Badge tone="amber">Only {product.stock} left</Badge>
            ) : (
              <Badge tone="green">
                <Check className="h-3 w-3" aria-hidden="true" /> In stock
              </Badge>
            )}
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="inline-flex items-center rounded-xl border border-slate-300 dark:border-slate-700" role="group" aria-label="Quantity">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                disabled={quantity <= 1 || soldOut}
                aria-label="Decrease quantity"
                className="flex h-11 w-11 items-center justify-center rounded-l-xl hover:bg-slate-100 disabled:opacity-40 dark:hover:bg-slate-800"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-12 text-center font-semibold" aria-live="polite">
                {soldOut ? 0 : quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(maxQty, q + 1))}
                disabled={quantity >= maxQty || soldOut}
                aria-label="Increase quantity"
                className="flex h-11 w-11 items-center justify-center rounded-r-xl hover:bg-slate-100 disabled:opacity-40 dark:hover:bg-slate-800"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <Button size="lg" className="flex-1 sm:flex-none sm:px-10" disabled={soldOut} onClick={() => addToCart(product, quantity)}>
              <ShoppingCart className="h-5 w-5" aria-hidden="true" />
              {soldOut ? 'Sold out' : 'Add to cart'}
            </Button>

            <Button
              size="lg"
              variant="secondary"
              onClick={() => toggleWishlist(product)}
              aria-pressed={wished}
              aria-label={wished ? 'Remove from wishlist' : 'Add to wishlist'}
              className="px-4"
            >
              <Heart className={cn('h-5 w-5', wished && 'fill-rose-500 text-rose-500')} />
            </Button>
          </div>

          <ul className="mt-8 grid gap-3 text-sm text-slate-600 sm:grid-cols-3 dark:text-slate-300">
            <li className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-brand-600" aria-hidden="true" /> Free shipping above ₹999
            </li>
            <li className="flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-brand-600" aria-hidden="true" /> 7-day returns
            </li>
            <li className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-brand-600" aria-hidden="true" /> 1-year warranty
            </li>
          </ul>

          {product.tags.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2">
              {product.tags.map((t) => (
                <Link
                  key={t}
                  to={`/shop?q=${encodeURIComponent(t)}`}
                  className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 hover:bg-brand-100 hover:text-brand-800 dark:bg-slate-800 dark:text-slate-300"
                >
                  #{t}
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      <section aria-labelledby="reviews-heading" className="mt-14">
        <h2 id="reviews-heading" className="mb-5 text-2xl font-bold text-slate-900 dark:text-white">
          Customer reviews
        </h2>
        {!reviews ? (
          <div className="space-y-3" role="status" aria-label="Loading reviews">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[16rem_1fr]">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center dark:border-slate-800 dark:bg-slate-900">
              <p className="text-5xl font-extrabold text-slate-900 dark:text-white">{(avg ?? product.rating).toFixed(1)}</p>
              <div className="mt-2 flex justify-center">
                <RatingStars rating={avg ?? product.rating} size="md" />
              </div>
              <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                {product.reviewCount.toLocaleString('en-IN')} ratings
              </p>
            </div>
            <ul className="space-y-4">
              {reviews.map((r) => (
                <li key={r.id} className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <RatingStars rating={r.rating} />
                    <time dateTime={r.date} className="text-xs text-slate-500 dark:text-slate-400">
                      {formatDate(r.date)}
                    </time>
                  </div>
                  <h3 className="mt-2 font-semibold text-slate-900 dark:text-white">{r.title}</h3>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">{r.comment}</p>
                  <p className="mt-3 text-xs font-medium text-slate-500 dark:text-slate-400">
                    {r.author} · Verified buyer
                  </p>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      <SimilarProducts product={product} products={products} />
    </div>
  )
}

import { Link } from 'react-router-dom'
import { buttonStyles } from '../components/ui/Button'

export default function NotFound() {
  return (
    <div className="flex flex-col items-center py-20 text-center">
      <p className="bg-gradient-to-r from-brand-500 to-ink-800 bg-clip-text text-8xl font-extrabold text-transparent">404</p>
      <h1 className="mt-4 text-2xl font-bold text-slate-900 dark:text-white">This page drifted out of orbit</h1>
      <p className="mt-2 max-w-md text-slate-600 dark:text-slate-400">
        The page you are looking for does not exist or has moved. Let us get you back to shopping.
      </p>
      <div className="mt-8 flex gap-3">
        <Link to="/" className={buttonStyles('primary', 'lg')}>
          Go home
        </Link>
        <Link to="/shop" className={buttonStyles('secondary', 'lg')}>
          Browse products
        </Link>
      </div>
    </div>
  )
}

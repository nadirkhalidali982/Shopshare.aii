import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { LayoutGrid, List, Search, SearchX, SlidersHorizontal, X } from 'lucide-react'
import FilterSidebar, { type ShopFilters } from '../components/product/FilterSidebar'
import ProductGrid from '../components/product/ProductGrid'
import SortDropdown from '../components/product/SortDropdown'
import Button from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { useDebounce } from '../hooks/useDebounce'
import { useProducts } from '../hooks/useProducts'
import { useBehaviorStore } from '../store/userBehaviorStore'
import type { Product, SortKey } from '../types'
import { cn, pluralize } from '../utils/format'
import { didYouMean, searchProducts } from '../utils/search'

const PAGE_SIZE = 12
const SORT_KEYS: SortKey[] = ['relevance', 'price-asc', 'price-desc', 'rating', 'newest']

function popularity(p: Product): number {
  return p.rating * Math.log10(p.reviewCount + 10)
}

export default function Shop() {
  const { products, loading, error } = useProducts()
  const [params, setParams] = useSearchParams()

  const q = params.get('q') ?? ''
  const filters: ShopFilters = {
    category: params.get('category') ?? '',
    min: params.get('min') ?? '',
    max: params.get('max') ?? '',
    rating: Number(params.get('rating') ?? 0) || 0,
    inStock: params.get('stock') === '1',
  }
  const sortParam = params.get('sort') as SortKey | null
  const sort: SortKey = sortParam && SORT_KEYS.includes(sortParam) ? sortParam : 'relevance'
  const view = params.get('view') === 'list' ? 'list' : 'grid'

  const [searchText, setSearchText] = useState(q)
  const [visible, setVisible] = useState(PAGE_SIZE)
  const [filtersOpen, setFiltersOpen] = useState(false)

  const recentSearches = useBehaviorStore((s) => s.recentSearches)
  const addSearch = useBehaviorStore((s) => s.addSearch)
  const clearSearches = useBehaviorStore((s) => s.clearSearches)

  const update = (changes: Record<string, string | null>) => {
    const next = new URLSearchParams(params)
    Object.entries(changes).forEach(([key, value]) => {
      if (value === null || value === '') next.delete(key)
      else next.set(key, value)
    })
    setParams(next, { replace: true })
  }

  // Keep the box in sync when the URL changes from elsewhere (navbar search, chips...).
  useEffect(() => {
    setSearchText(q)
  }, [q])

  // Push typing into the URL after a short pause.
  const debouncedText = useDebounce(searchText, 350)
  useEffect(() => {
    if (debouncedText.trim() !== q.trim()) {
      const next = new URLSearchParams(params)
      if (debouncedText.trim()) next.set('q', debouncedText.trim())
      else next.delete('q')
      setParams(next, { replace: true })
    }
    // Only react to the debounced text; params/q are read fresh on purpose.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedText])

  // Remember meaningful searches.
  useEffect(() => {
    if (q.trim().length >= 2) addSearch(q.trim())
  }, [q, addSearch])

  const filterKey = `${q}|${filters.category}|${filters.min}|${filters.max}|${filters.rating}|${filters.inStock}|${sort}`
  useEffect(() => {
    setVisible(PAGE_SIZE)
  }, [filterKey])

  const results = useMemo(() => {
    const minN = Number(filters.min)
    const maxN = Number(filters.max)
    let list = q.trim() ? searchProducts(products, q) : [...products]
    list = list.filter(
      (p) =>
        (!filters.category || p.category === filters.category) &&
        (!filters.min || p.price >= minN) &&
        (!filters.max || p.price <= maxN) &&
        p.rating >= filters.rating &&
        (!filters.inStock || p.stock > 0),
    )
    switch (sort) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        list.sort((a, b) => b.price - a.price)
        break
      case 'rating':
        list.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount)
        break
      case 'newest':
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        break
      default:
        if (!q.trim()) list.sort((a, b) => popularity(b) - popularity(a))
    }
    return list
    // filters is rebuilt each render; its fields are listed explicitly.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products, q, filters.category, filters.min, filters.max, filters.rating, filters.inStock, sort])

  const suggestion = useMemo(
    () => (results.length === 0 && q.trim() ? didYouMean(products, q) : null),
    [results.length, products, q],
  )

  const changeFilters = (changes: Partial<ShopFilters>) => {
    const mapped: Record<string, string | null> = {}
    if ('category' in changes) mapped.category = changes.category ?? null
    if ('min' in changes) mapped.min = changes.min ?? null
    if ('max' in changes) mapped.max = changes.max ?? null
    if ('rating' in changes) mapped.rating = changes.rating ? String(changes.rating) : null
    if ('inStock' in changes) mapped.stock = changes.inStock ? '1' : null
    update(mapped)
  }

  const resetFilters = () => update({ category: null, min: null, max: null, rating: null, stock: null })

  const shown = results.slice(0, visible)

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
          {filters.category || (q.trim() ? `Results for "${q.trim()}"` : 'All products')}
        </h1>
        {!loading && (
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400" aria-live="polite">
            {pluralize(results.length, 'product')} found
          </p>
        )}
      </div>

      <div className="mb-6 space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" aria-hidden="true" />
          <input
            type="search"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search products, brands, categories..."
            aria-label="Search products"
            className="h-12 w-full rounded-xl border border-slate-300 bg-white pl-12 pr-10 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 dark:border-slate-700 dark:bg-slate-900"
          />
          {searchText && (
            <button
              type="button"
              onClick={() => {
                setSearchText('')
                update({ q: null })
              }}
              aria-label="Clear search"
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-700"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {!q.trim() && recentSearches.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="text-slate-500 dark:text-slate-400">Recent:</span>
            {recentSearches.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => update({ q: s })}
                className="rounded-full border border-slate-300 px-3 py-1 text-xs font-medium text-slate-700 hover:border-brand-500 hover:text-brand-700 dark:border-slate-700 dark:text-slate-300"
              >
                {s}
              </button>
            ))}
            <button type="button" onClick={clearSearches} className="text-xs text-slate-500 underline">
              Clear
            </button>
          </div>
        )}
      </div>

      <div className="mb-5 flex items-center justify-between gap-3">
        <Button variant="secondary" size="sm" className="lg:hidden" onClick={() => setFiltersOpen((o) => !o)} aria-expanded={filtersOpen}>
          <SlidersHorizontal className="h-4 w-4" aria-hidden="true" /> Filters
        </Button>
        <div className="ml-auto flex items-center gap-3">
          <SortDropdown value={sort} onChange={(value) => update({ sort: value === 'relevance' ? null : value })} />
          <div className="hidden rounded-xl border border-slate-300 p-1 sm:flex dark:border-slate-700" role="group" aria-label="Layout">
            <button
              type="button"
              onClick={() => update({ view: null })}
              aria-label="Grid view"
              aria-pressed={view === 'grid'}
              className={cn('rounded-lg p-1.5', view === 'grid' ? 'bg-brand-600 text-white' : 'text-slate-500')}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => update({ view: 'list' })}
              aria-label="List view"
              aria-pressed={view === 'list'}
              className={cn('rounded-lg p-1.5', view === 'list' ? 'bg-brand-600 text-white' : 'text-slate-500')}
            >
              <List className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[17rem_1fr]">
        <div className={cn(filtersOpen ? 'block' : 'hidden', 'lg:block')}>
          <FilterSidebar filters={filters} onChange={changeFilters} onReset={resetFilters} className="lg:sticky lg:top-24" />
        </div>

        <div>
          {error ? (
            <EmptyState title="Could not load products" description={error} action={<Button onClick={() => window.location.reload()}>Try again</Button>} />
          ) : !loading && results.length === 0 ? (
            <EmptyState
              icon={<SearchX className="h-8 w-8" />}
              title="No products found"
              description="Try a different spelling, or remove some filters."
              action={
                <div className="flex flex-col items-center gap-3">
                  {suggestion && (
                    <button
                      type="button"
                      onClick={() => update({ q: suggestion })}
                      className="text-sm text-slate-600 dark:text-slate-300"
                    >
                      Did you mean <span className="font-bold text-brand-600 underline dark:text-brand-300">{suggestion}</span>?
                    </button>
                  )}
                  <Button
                    variant="secondary"
                    onClick={() => {
                      setSearchText('')
                      setParams({}, { replace: true })
                    }}
                  >
                    Clear search and filters
                  </Button>
                </div>
              }
            />
          ) : (
            <>
              <ProductGrid products={shown} loading={loading} layout={view} columns={3} skeletonCount={6} />
              {!loading && results.length > visible && (
                <div className="mt-8 text-center">
                  <Button variant="secondary" size="lg" onClick={() => setVisible((v) => v + PAGE_SIZE)}>
                    Load more ({results.length - visible} remaining)
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

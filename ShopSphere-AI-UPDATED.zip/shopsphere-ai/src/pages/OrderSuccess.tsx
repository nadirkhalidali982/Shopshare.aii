import { Link, useParams } from 'react-router-dom'
import { CheckCircle2, Package } from 'lucide-react'
import Button, { buttonStyles } from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { useOrderStore } from '../store/orderStore'
import { formatPrice } from '../utils/format'

export default function OrderSuccess() {
  const { id } = useParams<{ id: string }>()
  const order = useOrderStore((s) => s.orders.find((o) => o.id === id))

  if (!order) {
    return (
      <EmptyState
        icon={<Package className="h-8 w-8" />}
        title="Order not found"
        description="We could not find this order on this device."
        action={
          <Link to="/orders" className={buttonStyles()}>
            View my orders
          </Link>
        }
      />
    )
  }

  return (
    <div className="mx-auto max-w-xl text-center">
      <div className="mx-auto flex h-20 w-20 animate-pop-in items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300">
        <CheckCircle2 className="h-11 w-11" aria-hidden="true" />
      </div>
      <h1 className="mt-6 text-3xl font-extrabold text-slate-900 dark:text-white">Order placed!</h1>
      <p className="mt-2 text-slate-600 dark:text-slate-300">
        Thank you, {order.address.fullName.split(' ')[0]}. Your order is confirmed and will reach you in 3 to 5 days.
      </p>

      <div className="mt-8 rounded-2xl border border-slate-200 bg-white p-5 text-left dark:border-slate-800 dark:bg-slate-900">
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-slate-500 dark:text-slate-400">Order ID</dt>
            <dd className="font-mono font-semibold text-slate-900 dark:text-white">{order.id}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-slate-500 dark:text-slate-400">Items</dt>
            <dd className="font-semibold text-slate-900 dark:text-white">{order.items.reduce((n, i) => n + i.quantity, 0)}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-slate-500 dark:text-slate-400">Payment</dt>
            <dd className="font-semibold text-slate-900 dark:text-white">{order.paymentLabel}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-slate-500 dark:text-slate-400">Deliver to</dt>
            <dd className="text-right font-semibold text-slate-900 dark:text-white">
              {order.address.city}, {order.address.state} - {order.address.pincode}
            </dd>
          </div>
          <div className="flex justify-between gap-4 border-t border-slate-200 pt-3 dark:border-slate-800">
            <dt className="font-bold text-slate-900 dark:text-white">Total</dt>
            <dd className="text-lg font-extrabold text-slate-900 dark:text-white">{formatPrice(order.total)}</dd>
          </div>
        </dl>
      </div>

      <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
        <Link to="/orders" className={buttonStyles('primary', 'lg')}>
          View my orders
        </Link>
        <Link to="/shop" className={buttonStyles('secondary', 'lg')}>
          Continue shopping
        </Link>
      </div>
      <Button variant="ghost" className="mt-2" onClick={() => window.print()}>
        Print receipt
      </Button>
    </div>
  )
}

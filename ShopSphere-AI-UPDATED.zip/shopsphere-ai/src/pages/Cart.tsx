import { useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, ShoppingBag } from 'lucide-react'
import CartItemRow from '../components/cart/CartItemRow'
import OrderSummary from '../components/cart/OrderSummary'
import ProductGrid from '../components/product/ProductGrid'
import Button, { buttonStyles } from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { ProductGridSkeleton } from '../components/ui/Skeleton'
import { useProducts } from '../hooks/useProducts'
import { useRecommendations } from '../hooks/useRecommendations'
import { useCartStore } from '../store/cartStore'
import type { CartLine } from '../types'
import { computeTotals } from '../utils/pricing'

export default function Cart() {
  const navigate = useNavigate()
  const { products, loading } = useProducts()
  const items = useCartStore((s) => s.items)
  const promoCode = useCartStore((s) => s.promoCode)
  const setQuantity = useCartStore((s) => s.setQuantity)
  const removeItem = useCartStore((s) => s.removeItem)
  const { picks } = useRecommendations(products, 4)

  const lines: CartLine[] = useMemo(
    () =>
      items
        .map((i) => {
          const product = products.find((p) => p.id === i.productId)
          return product ? { product, quantity: i.quantity } : null
        })
        .filter((l): l is CartLine => l !== null),
    [items, products],
  )
  const totals = useMemo(() => computeTotals(lines, promoCode), [lines, promoCode])

  if (loading && items.length > 0) return <ProductGridSkeleton count={3} />

  if (lines.length === 0) {
    return (
      <div className="space-y-12">
        <EmptyState
          icon={<ShoppingBag className="h-8 w-8" />}
          title="Your cart is empty"
          description="Looks like you have not added anything yet. Here are some picks to get you started."
          action={
            <Link to="/shop" className={buttonStyles()}>
              Start shopping
            </Link>
          }
        />
        {picks.length > 0 && (
          <section aria-labelledby="cart-picks">
            <h2 id="cart-picks" className="mb-5 text-2xl font-bold text-slate-900 dark:text-white">
              You might like
            </h2>
            <ProductGrid products={picks.map((r) => r.product)} />
          </section>
        )}
      </div>
    )
  }

  const stockProblem = lines.some((l) => l.product.stock === 0)

  return (
    <div>
      <h1 className="mb-6 text-3xl font-extrabold text-slate-900 dark:text-white">
        Shopping cart <span className="text-lg font-semibold text-slate-500">({totals.itemCount})</span>
      </h1>
      <div className="grid gap-8 lg:grid-cols-[1fr_24rem]">
        <ul className="space-y-4">
          {lines.map(({ product, quantity }) => (
            <CartItemRow
              key={product.id}
              product={product}
              quantity={quantity}
              onQuantityChange={(q) => setQuantity(product.id, q, Math.min(10, product.stock))}
              onRemove={() => removeItem(product.id)}
            />
          ))}
        </ul>
        <div>
          <OrderSummary totals={totals} className="lg:sticky lg:top-24">
            {stockProblem && (
              <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">
                Some items are out of stock. Remove them to continue.
              </p>
            )}
            <Button size="lg" className="w-full" disabled={stockProblem} onClick={() => navigate('/checkout')}>
              Proceed to checkout <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Link to="/shop" className="block text-center text-sm font-medium text-brand-600 hover:underline dark:text-brand-300">
              Continue shopping
            </Link>
          </OrderSummary>
        </div>
      </div>
    </div>
  )
}

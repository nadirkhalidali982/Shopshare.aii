import { useMemo, useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { ArrowLeft, ArrowRight, Lock } from 'lucide-react'
import { placeOrder } from '../api/orders'
import OrderSummary from '../components/cart/OrderSummary'
import AddressForm from '../components/checkout/AddressForm'
import PaymentForm from '../components/checkout/PaymentForm'
import ReviewStep from '../components/checkout/ReviewStep'
import Stepper from '../components/checkout/Stepper'
import Button from '../components/ui/Button'
import { ProductGridSkeleton } from '../components/ui/Skeleton'
import { useProducts } from '../hooks/useProducts'
import { useAuthStore } from '../store/authStore'
import { useCartStore } from '../store/cartStore'
import { useOrderStore } from '../store/orderStore'
import { useUiStore } from '../store/uiStore'
import { useBehaviorStore } from '../store/userBehaviorStore'
import type { Address, CartLine, PaymentDraft } from '../types'
import { computeTotals } from '../utils/pricing'
import {
  emptyAddress,
  emptyPayment,
  hasErrors,
  validateAddress,
  validatePayment,
  type AddressErrors,
  type PaymentErrors,
} from '../utils/validators'

const STEPS = ['Address', 'Payment', 'Review']

export default function Checkout() {
  const navigate = useNavigate()
  const { products, loading } = useProducts()
  const user = useAuthStore((s) => s.user)
  const updateUser = useAuthStore((s) => s.updateUser)
  const items = useCartStore((s) => s.items)
  const promoCode = useCartStore((s) => s.promoCode)
  const clearCart = useCartStore((s) => s.clear)
  const addOrder = useOrderStore((s) => s.addOrder)
  const track = useBehaviorStore((s) => s.track)
  const toast = useUiStore((s) => s.pushToast)

  const [step, setStep] = useState(0)
  const [address, setAddress] = useState<Address>(() => user?.address ?? { ...emptyAddress, fullName: user?.name ?? '', phone: user?.phone ?? '' })
  const [payment, setPayment] = useState<PaymentDraft>(emptyPayment)
  const [addressErrors, setAddressErrors] = useState<AddressErrors>({})
  const [paymentErrors, setPaymentErrors] = useState<PaymentErrors>({})
  const [placing, setPlacing] = useState(false)

  const lines: CartLine[] = useMemo(
    () =>
      items
        .map((i) => {
          const product = products.find((p) => p.id === i.productId)
          return product ? { product, quantity: i.quantity } : null
        })
        .filter((l): l is CartLine => l !== null),
    [items, products],
  )
  const totals = useMemo(() => computeTotals(lines, promoCode), [lines, promoCode])

  if (loading && items.length > 0) return <ProductGridSkeleton count={3} />
  // An empty cart has nothing to check out. (While placing, the cart is cleared first, so wait.)
  if (!placing && lines.length === 0) return <Navigate to="/cart" replace />

  const goNext = () => {
    if (step === 0) {
      const errors = validateAddress(address)
      setAddressErrors(errors)
      if (hasErrors(errors)) {
        toast('Please fix the highlighted fields', 'error')
        return
      }
    }
    if (step === 1) {
      const errors = validatePayment(payment)
      setPaymentErrors(errors)
      if (hasErrors(errors)) {
        toast('Please check your payment details', 'error')
        return
      }
    }
    setStep((s) => s + 1)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const place = async () => {
    if (!user) return
    setPlacing(true)
    try {
      const order = await placeOrder({ user, lines, address, payment, totals, promoCode })
      addOrder(order)
      order.items.forEach((i) => track(i.productId, 'purchase'))
      // Save the address for next time. Card details are never stored.
      void updateUser({ address, phone: address.phone })
      clearCart()
      navigate(`/order-success/${order.id}`, { replace: true })
    } catch {
      toast('Could not place your order. Please try again.', 'error')
      setPlacing(false)
    }
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">Checkout</h1>
        <p className="hidden items-center gap-1 text-sm text-slate-500 sm:flex dark:text-slate-400">
          <Lock className="h-4 w-4" aria-hidden="true" /> Demo checkout, no real payment
        </p>
      </div>

      <div className="mb-8 max-w-2xl">
        <Stepper steps={STEPS} current={step} />
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_24rem]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-7 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="mb-5 text-xl font-bold text-slate-900 dark:text-white">
            {step === 0 && 'Delivery address'}
            {step === 1 && 'Payment method'}
            {step === 2 && 'Review your order'}
          </h2>

          {step === 0 && (
            <AddressForm
              value={address}
              errors={addressErrors}
              onChange={(changes) => {
                setAddress((a) => ({ ...a, ...changes }))
                setAddressErrors((e) => {
                  const next = { ...e }
                  Object.keys(changes).forEach((k) => delete next[k as keyof Address])
                  return next
                })
              }}
            />
          )}
          {step === 1 && (
            <PaymentForm
              value={payment}
              errors={paymentErrors}
              onChange={(changes) => {
                setPayment((p) => ({ ...p, ...changes }))
                setPaymentErrors((e) => {
                  const next = { ...e }
                  Object.keys(changes).forEach((k) => delete next[k as keyof PaymentDraft])
                  return next
                })
              }}
            />
          )}
          {step === 2 && (
            <ReviewStep lines={lines} address={address} payment={payment} onEditAddress={() => setStep(0)} onEditPayment={() => setStep(1)} />
          )}

          <div className="mt-8 flex items-center justify-between gap-3">
            {step === 0 ? (
              <Link to="/cart" className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-brand-600 dark:text-slate-300">
                <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back to cart
              </Link>
            ) : (
              <Button variant="secondary" onClick={() => setStep((s) => s - 1)} disabled={placing}>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back
              </Button>
            )}
            {step < 2 ? (
              <Button size="lg" onClick={goNext}>
                Continue <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Button>
            ) : (
              <Button size="lg" loading={placing} onClick={() => void place()}>
                Place order · {new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(totals.total)}
              </Button>
            )}
          </div>
        </div>

        <OrderSummary totals={totals} showPromo={false} className="h-fit lg:sticky lg:top-24" />
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronDown, Package } from 'lucide-react'
import { deriveOrderStatus, ORDER_STEPS } from '../api/orders'
import ProductImage from '../components/product/ProductImage'
import Badge from '../components/ui/Badge'
import { buttonStyles } from '../components/ui/Button'
import EmptyState from '../components/ui/EmptyState'
import { useAuthStore } from '../store/authStore'
import { useOrderStore } from '../store/orderStore'
import type { Order, OrderStatus } from '../types'
import { cn, formatDateTime, formatPrice, pluralize } from '../utils/format'

const statusTone: Record<OrderStatus, 'blue' | 'amber' | 'brand' | 'green'> = {
  Placed: 'blue',
  Packed: 'amber',
  Shipped: 'brand',
  Delivered: 'green',
}

function OrderCard({ order }: { order: Order }) {
  const [open, setOpen] = useState(false)
  const status = deriveOrderStatus(order.createdAt)
  const stepIndex = ORDER_STEPS.indexOf(status)
  const panelId = `order-${order.id}`

  return (
    <li className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls={panelId}
        className="flex w-full flex-wrap items-center gap-x-6 gap-y-2 p-4 text-left sm:p-5"
      >
        <div className="flex -space-x-3">
          {order.items.slice(0, 3).map((i) => (
            <span key={i.productId} className="h-12 w-12 overflow-hidden rounded-xl border-2 border-white bg-slate-100 dark:border-slate-900 dark:bg-slate-800">
              <ProductImage src={i.image} alt={i.name} category="Electronics" className="h-full w-full object-cover" />
            </span>
          ))}
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-mono text-sm font-bold text-slate-900 dark:text-white">{order.id}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {formatDateTime(order.createdAt)} · {pluralize(order.items.reduce((n, i) => n + i.quantity, 0), 'item')}
          </p>
        </div>
        <Badge tone={statusTone[status]}>{status}</Badge>
        <p className="text-base font-extrabold text-slate-900 dark:text-white">{formatPrice(order.total)}</p>
        <ChevronDown className={cn('h-5 w-5 text-slate-400 transition-transform', open && 'rotate-180')} aria-hidden="true" />
      </button>

      {open && (
        <div id={panelId} className="space-y-5 border-t border-slate-200 p-4 sm:p-5 dark:border-slate-800">
          <ol className="flex items-center" aria-label="Order progress">
            {ORDER_STEPS.map((s, i) => (
              <li key={s} className={cn('flex items-center text-xs font-semibold', i < ORDER_STEPS.length - 1 && 'flex-1')}>
                <span
                  className={cn(
                    'flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px]',
                    i <= stepIndex ? 'bg-brand-600 text-white' : 'bg-slate-200 text-slate-500 dark:bg-slate-800',
                  )}
                >
                  {i + 1}
                </span>
                <span className={cn('ml-1.5 hidden sm:inline', i <= stepIndex ? 'text-slate-900 dark:text-white' : 'text-slate-400')}>{s}</span>
                {i < ORDER_STEPS.length - 1 && (
                  <span className={cn('mx-2 h-0.5 flex-1 rounded', i < stepIndex ? 'bg-brand-500' : 'bg-slate-200 dark:bg-slate-800')} />
                )}
              </li>
            ))}
          </ol>

          <ul className="divide-y divide-slate-200 dark:divide-slate-800">
            {order.items.map((i) => (
              <li key={i.productId} className="flex items-center gap-3 py-3">
                <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800">
                  <ProductImage src={i.image} alt={i.name} category="Electronics" className="h-full w-full object-cover" />
                </div>
                <div className="min-w-0 flex-1">
                  <Link to={`/product/${i.productId}`} className="line-clamp-1 text-sm font-semibold text-slate-900 hover:text-brand-600 dark:text-white">
                    {i.name}
                  </Link>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Qty {i.quantity} × {formatPrice(i.price)}
                  </p>
                </div>
                <p className="text-sm font-bold text-slate-900 dark:text-white">{formatPrice(i.price * i.quantity)}</p>
              </li>
            ))}
          </ul>

          <div className="grid gap-4 text-sm sm:grid-cols-2">
            <div>
              <h3 className="mb-1 font-bold text-slate-900 dark:text-white">Delivery address</h3>
              <p className="text-slate-600 dark:text-slate-300">
                {order.address.fullName}
                <br />
                {order.address.line1}
                <br />
                {order.address.city}, {order.address.state} - {order.address.pincode}
              </p>
            </div>
            <dl className="space-y-1">
              <div className="flex justify-between">
                <dt className="text-slate-500">Subtotal</dt>
                <dd>{formatPrice(order.subtotal)}</dd>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-emerald-600">
                  <dt>Discount{order.promoCode ? ` (${order.promoCode})` : ''}</dt>
                  <dd>− {formatPrice(order.discount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-slate-500">Shipping</dt>
                <dd>{order.shipping === 0 ? 'Free' : formatPrice(order.shipping)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-500">Payment</dt>
                <dd>{order.paymentLabel}</dd>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1 font-bold dark:border-slate-800">
                <dt>Total</dt>
                <dd>{formatPrice(order.total)}</dd>
              </div>
            </dl>
          </div>
        </div>
      )}
    </li>
  )
}

export default function Orders() {
  const user = useAuthStore((s) => s.user)
  const allOrders = useOrderStore((s) => s.orders)
  // Show only this account's orders when several people share one browser.
  const orders = allOrders.filter((o) => o.userId === user?.id)

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="mb-6 text-3xl font-extrabold text-slate-900 dark:text-white">My orders</h1>
      {orders.length === 0 ? (
        <EmptyState
          icon={<Package className="h-8 w-8" />}
          title="No orders yet"
          description="When you place an order, it will show up here."
          action={
            <Link to="/shop" className={buttonStyles()}>
              Start shopping
            </Link>
          }
        />
      ) : (
        <ul className="space-y-4">
          {orders.map((o) => (
            <OrderCard key={o.id} order={o} />
          ))}
        </ul>
      )}
    </div>
  )
}

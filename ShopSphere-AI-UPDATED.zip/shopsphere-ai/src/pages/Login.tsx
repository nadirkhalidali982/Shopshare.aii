import { useState, type FormEvent } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { DEMO_CREDENTIALS } from '../api/auth'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'
import { useAuthStore } from '../store/authStore'
import { useUiStore } from '../store/uiStore'
import { validateEmail, validatePassword } from '../utils/validators'

interface LocationState {
  from?: string
}

export default function Login() {
  const navigate = useNavigate()
  const location = useLocation()
  const from = (location.state as LocationState | null)?.from ?? '/'
  const user = useAuthStore((s) => s.user)
  const login = useAuthStore((s) => s.login)
  const toast = useUiStore((s) => s.pushToast)

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState<{ email?: string; password?: string; form?: string }>({})
  const [loading, setLoading] = useState(false)

  if (user) return <Navigate to={from} replace />

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    const next = {
      email: validateEmail(email) ?? undefined,
      password: validatePassword(password) ?? undefined,
    }
    setErrors(next)
    if (next.email || next.password) return
    setLoading(true)
    try {
      await login(email, password)
      toast('Welcome back!')
      navigate(from, { replace: true })
    } catch (err) {
      setErrors({ form: err instanceof Error ? err.message : 'Could not log in' })
      setLoading(false)
    }
  }

  const fillDemo = () => {
    setEmail(DEMO_CREDENTIALS.email)
    setPassword(DEMO_CREDENTIALS.password)
    setErrors({})
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8 dark:border-slate-800 dark:bg-slate-900">
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Welcome back</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Log in to continue shopping</p>

        <form onSubmit={(e) => void submit(e)} noValidate className="mt-6 space-y-4">
          {errors.form && (
            <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-700 dark:bg-red-950/40 dark:text-red-300">
              {errors.form}
            </p>
          )}
          <Input
            label="Email"
            type="email"
            autoComplete="email"
            value={email}
            error={errors.email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            label="Password"
            type="password"
            autoComplete="current-password"
            value={password}
            error={errors.password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button type="submit" size="lg" className="w-full" loading={loading}>
            Log in
          </Button>
        </form>

        <div className="mt-4 rounded-xl bg-brand-50 p-3 text-sm dark:bg-brand-900/20">
          <p className="text-slate-700 dark:text-slate-300">
            Just exploring? Use the demo account.{' '}
            <button type="button" onClick={fillDemo} className="font-semibold text-brand-700 underline dark:text-brand-300">
              Fill demo login
            </button>
          </p>
        </div>

        <p className="mt-6 text-center text-sm text-slate-600 dark:text-slate-400">
          New here?{' '}
          <Link to="/register" state={{ from }} className="font-semibold text-brand-600 hover:underline dark:text-brand-300">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  )
}

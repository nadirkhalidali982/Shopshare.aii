import { useState } from 'react'
import { LogOut, Moon, Sun, Trash2 } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'
import Modal from '../components/ui/Modal'
import { indianStates } from '../data/indianStates'
import { useAuthStore } from '../store/authStore'
import { useCartStore } from '../store/cartStore'
import { useChatStore } from '../store/chatStore'
import { useOrderStore } from '../store/orderStore'
import { useUiStore } from '../store/uiStore'
import { useBehaviorStore } from '../store/userBehaviorStore'
import { useWishlistStore } from '../store/wishlistStore'
import type { Address } from '../types'
import { emptyAddress, hasErrors, validateAddress, validateName, validatePhone, type AddressErrors } from '../utils/validators'

export default function Profile() {
  const navigate = useNavigate()
  const user = useAuthStore((s) => s.user)
  const updateUser = useAuthStore((s) => s.updateUser)
  const logout = useAuthStore((s) => s.logout)
  const theme = useUiStore((s) => s.theme)
  const setTheme = useUiStore((s) => s.setTheme)
  const toast = useUiStore((s) => s.pushToast)

  const [name, setName] = useState(user?.name ?? '')
  const [phone, setPhone] = useState(user?.phone ?? '')
  const [address, setAddress] = useState<Address>(user?.address ?? emptyAddress)
  const [nameError, setNameError] = useState<string | undefined>()
  const [phoneError, setPhoneError] = useState<string | undefined>()
  const [addressErrors, setAddressErrors] = useState<AddressErrors>({})
  const [saving, setSaving] = useState(false)
  const [confirmOpen, setConfirmOpen] = useState(false)

  if (!user) return null

  const save = async () => {
    const nErr = validateName(name) ?? undefined
    const pErr = phone.trim() ? (validatePhone(phone) ?? undefined) : undefined
    setNameError(nErr)
    setPhoneError(pErr)

    // The address is optional, but if the person started filling it, it must be complete.
    const addressStarted = Object.values(address).some((v) => v.trim() !== '')
    const aErr = addressStarted ? validateAddress(address) : {}
    setAddressErrors(aErr)

    if (nErr || pErr || hasErrors(aErr)) {
      toast('Please fix the highlighted fields', 'error')
      return
    }
    setSaving(true)
    await updateUser({ name: name.trim(), phone: phone.trim(), address: addressStarted ? address : undefined })
    setSaving(false)
    toast('Profile saved')
  }

  const clearAllData = () => {
    useCartStore.getState().clear()
    useWishlistStore.setState({ ids: [] })
    useOrderStore.setState({ orders: [] })
    useBehaviorStore.setState({ events: [], recentlyViewed: [], recentSearches: [] })
    useChatStore.getState().clear()
    setConfirmOpen(false)
    toast('Cart, wishlist, orders, history and chat were cleared', 'info')
  }

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div className="flex items-center gap-4">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-600 text-2xl font-extrabold text-white">
          {user.name.charAt(0).toUpperCase()}
        </span>
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">My profile</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">{user.email}</p>
        </div>
      </div>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-7 dark:border-slate-800 dark:bg-slate-900" aria-labelledby="details">
        <h2 id="details" className="mb-5 text-lg font-bold text-slate-900 dark:text-white">
          Personal details
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Input label="Full name" value={name} error={nameError} onChange={(e) => setName(e.target.value)} />
          <Input label="Mobile number" type="tel" inputMode="numeric" value={phone} error={phoneError} onChange={(e) => setPhone(e.target.value)} />
          <Input label="Email" value={user.email} disabled hint="Email cannot be changed in this demo" className="sm:col-span-2" />
        </div>

        <h3 className="mb-4 mt-8 text-base font-bold text-slate-900 dark:text-white">Saved address</h3>
        <div className="grid gap-4 sm:grid-cols-2">
          <Input
            className="sm:col-span-2"
            label="Address"
            value={address.line1}
            error={addressErrors.line1}
            onChange={(e) => setAddress((a) => ({ ...a, line1: e.target.value }))}
          />
          <Input
            label="Recipient name"
            value={address.fullName}
            error={addressErrors.fullName}
            onChange={(e) => setAddress((a) => ({ ...a, fullName: e.target.value }))}
          />
          <Input
            label="Recipient mobile"
            inputMode="numeric"
            value={address.phone}
            error={addressErrors.phone}
            onChange={(e) => setAddress((a) => ({ ...a, phone: e.target.value }))}
          />
          <Input label="City" value={address.city} error={addressErrors.city} onChange={(e) => setAddress((a) => ({ ...a, city: e.target.value }))} />
          <div>
            <label htmlFor="profile-state" className="mb-1.5 block text-sm font-medium text-slate-700 dark:text-slate-300">
              State
            </label>
            <select
              id="profile-state"
              value={address.state}
              onChange={(e) => setAddress((a) => ({ ...a, state: e.target.value }))}
              className={`h-11 w-full rounded-xl border bg-white px-3 text-sm dark:bg-slate-900 ${
                addressErrors.state ? 'border-red-500' : 'border-slate-300 dark:border-slate-700'
              }`}
            >
              <option value="">Select state</option>
              {indianStates.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            {addressErrors.state && <p className="mt-1 text-xs text-red-600">{addressErrors.state}</p>}
          </div>
          <Input
            label="PIN code"
            inputMode="numeric"
            maxLength={6}
            value={address.pincode}
            error={addressErrors.pincode}
            onChange={(e) => setAddress((a) => ({ ...a, pincode: e.target.value.replace(/\D/g, '') }))}
          />
        </div>

        <div className="mt-6">
          <Button loading={saving} onClick={() => void save()}>
            Save changes
          </Button>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 bg-white p-5 sm:p-7 dark:border-slate-800 dark:bg-slate-900" aria-labelledby="prefs">
        <h2 id="prefs" className="mb-4 text-lg font-bold text-slate-900 dark:text-white">
          Preferences
        </h2>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-medium text-slate-900 dark:text-white">Appearance</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Currently using {theme} mode</p>
          </div>
          <div className="inline-flex rounded-xl border border-slate-300 p-1 dark:border-slate-700" role="group" aria-label="Theme">
            <button
              type="button"
              onClick={() => setTheme('light')}
              aria-pressed={theme === 'light'}
              className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium ${theme === 'light' ? 'bg-brand-600 text-white' : 'text-slate-600 dark:text-slate-300'}`}
            >
              <Sun className="h-4 w-4" aria-hidden="true" /> Light
            </button>
            <button
              type="button"
              onClick={() => setTheme('dark')}
              aria-pressed={theme === 'dark'}
              className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium ${theme === 'dark' ? 'bg-brand-600 text-white' : 'text-slate-600 dark:text-slate-300'}`}
            >
              <Moon className="h-4 w-4" aria-hidden="true" /> Dark
            </button>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-red-200 bg-red-50/50 p-5 sm:p-7 dark:border-red-900/60 dark:bg-red-950/20" aria-labelledby="danger">
        <h2 id="danger" className="mb-1 text-lg font-bold text-slate-900 dark:text-white">
          Account actions
        </h2>
        <p className="mb-4 text-sm text-slate-600 dark:text-slate-400">
          Everything in this demo is stored in your browser only. You can clear it any time.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="secondary" onClick={() => { logout(); navigate('/') }}>
            <LogOut className="h-4 w-4" aria-hidden="true" /> Log out
          </Button>
          <Button variant="danger" onClick={() => setConfirmOpen(true)}>
            <Trash2 className="h-4 w-4" aria-hidden="true" /> Clear all my data
          </Button>
        </div>
      </section>

      <Modal open={confirmOpen} onClose={() => setConfirmOpen(false)} title="Clear all data?">
        <p className="text-sm text-slate-600 dark:text-slate-300">
          This removes your cart, wishlist, orders, browsing history, recent searches and assistant chat from this
          browser. Your account stays. This cannot be undone.
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <Button variant="secondary" onClick={() => setConfirmOpen(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={clearAllData}>
            Yes, clear everything
          </Button>
        </div>
      </Modal>
    </div>
  )
}

import { useMemo, useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, BadgePercent, RotateCcw, Search, ShieldCheck, Sparkles, Truck } from 'lucide-react'
import ProductGrid from '../components/product/ProductGrid'
import { buttonStyles } from '../components/ui/Button'
import { categories } from '../data/categories'
import { useProducts } from '../hooks/useProducts'
import { useRecommendations } from '../hooks/useRecommendations'
import { useUiStore } from '../store/uiStore'
import { useBehaviorStore } from '../store/userBehaviorStore'
import { discountPercent } from '../utils/format'

const perks = [
  { icon: Truck, title: 'Free shipping', text: 'On orders above ₹999' },
  { icon: RotateCcw, title: 'Easy returns', text: '7-day hassle-free returns' },
  { icon: ShieldCheck, title: 'Secure checkout', text: 'Your data stays on your device' },
  { icon: Sparkles, title: 'AI picks', text: 'Recommendations made for you' },
]

function SectionHeader({ title, subtitle, to }: { title: string; subtitle?: string; to?: string }) {
  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h2>
        {subtitle && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{subtitle}</p>}
      </div>
      {to && (
        <Link to={to} className="flex items-center gap-1 text-sm font-semibold text-brand-600 hover:underline dark:text-brand-300">
          View all <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      )}
    </div>
  )
}

export default function Home() {
  const navigate = useNavigate()
  const { products, loading } = useProducts()
  const { picks, personalised } = useRecommendations(products, 8)
  const recentIds = useBehaviorStore((s) => s.recentlyViewed)
  const setAssistantOpen = useUiStore((s) => s.setAssistantOpen)
  const [query, setQuery] = useState('')

  const reasons = useMemo(() => Object.fromEntries(picks.map((r) => [r.product.id, r.reason])), [picks])
  const trending = useMemo(() => products.filter((p) => p.isTrending).slice(0, 4), [products])
  const deals = useMemo(
    () =>
      [...products]
        .filter((p) => p.stock > 0)
        .sort((a, b) => discountPercent(b.price, b.originalPrice) - discountPercent(a.price, a.originalPrice))
        .slice(0, 4),
    [products],
  )
  const recent = useMemo(
    () => recentIds.map((id) => products.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => Boolean(p)).slice(0, 4),
    [recentIds, products],
  )

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const q = query.trim()
    navigate(q ? `/shop?q=${encodeURIComponent(q)}` : '/shop')
  }

  return (
    <div className="space-y-14">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ink-900 via-ink-800 to-brand-700 px-6 py-12 text-white sm:px-12 sm:py-16">
        <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-brand-400/20 blur-3xl" aria-hidden="true" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-72 w-72 rounded-full bg-sky-400/10 blur-3xl" aria-hidden="true" />
        <div className="relative max-w-2xl animate-fade-up">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold backdrop-blur">
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" /> Personalized Shopping, Powered by Intelligence
          </p>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
            Shopping that gets <span className="text-brand-300">you</span>.
          </h1>
          <p className="mt-4 max-w-xl text-base text-slate-200 sm:text-lg">
            Smart picks based on what you love, search that understands typos, and an AI assistant that finds the right
            product for your budget.
          </p>
          <form onSubmit={submit} role="search" className="mt-8 flex max-w-xl gap-2">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" aria-hidden="true" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Try "shos" or "wireless headphones"'
                aria-label="Search products"
                className="h-13 w-full rounded-xl border-0 bg-white py-3.5 pl-12 pr-4 text-slate-900 shadow-lg placeholder:text-slate-400 focus:outline-none focus:ring-4 focus:ring-brand-400/50"
              />
            </div>
            <button type="submit" className="rounded-xl bg-brand-500 px-6 font-semibold text-white shadow-lg hover:bg-brand-400">
              Search
            </button>
          </form>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/shop" className={buttonStyles('secondary', 'md', 'border-0 bg-white/10 text-white hover:bg-white/20 dark:bg-white/10 dark:text-white dark:hover:bg-white/20')}>
              Browse all products
            </Link>
            <button
              type="button"
              onClick={() => setAssistantOpen(true)}
              className={buttonStyles('secondary', 'md', 'border-0 bg-white/10 text-white hover:bg-white/20 dark:bg-white/10 dark:text-white dark:hover:bg-white/20')}
            >
              <Sparkles className="h-4 w-4" aria-hidden="true" /> Ask the AI assistant
            </button>
          </div>
        </div>
      </section>

      {/* Perks */}
      <section aria-label="Why shop with us" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {perks.map(({ icon: Icon, title, text }) => (
          <div key={title} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-900/30 dark:text-brand-300">
              <Icon className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <p className="text-sm font-bold text-slate-900 dark:text-white">{title}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{text}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Recommended */}
      <section aria-labelledby="for-you">
        <div id="for-you">
          <SectionHeader
            title={personalised ? 'Recommended for you' : 'Top picks for you'}
            subtitle={
              personalised
                ? 'Ranked using what you viewed, saved and added to your cart'
                : 'Trending and top-rated right now. Browse a few products and these will adapt to you.'
            }
            to="/shop"
          />
        </div>
        <ProductGrid products={picks.map((r) => r.product)} loading={loading} reasons={reasons} skeletonCount={8} />
      </section>

      {/* Categories */}
      <section aria-labelledby="categories">
        <h2 id="categories" className="mb-5 text-2xl font-bold text-slate-900 dark:text-white">
          Shop by category
        </h2>
        <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-6">
          {categories.map((c) => (
            <Link
              key={c.name}
              to={`/shop?category=${encodeURIComponent(c.name)}`}
              className={`group relative overflow-hidden rounded-2xl bg-gradient-to-br ${c.gradient} p-4 text-white shadow-sm transition-transform hover:-translate-y-1 hover:shadow-lg`}
            >
              <span className="text-3xl" aria-hidden="true">
                {c.emoji}
              </span>
              <p className="mt-6 text-sm font-bold leading-tight">{c.name}</p>
              <p className="text-xs text-white/80">{c.tagline}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section aria-labelledby="trending">
        <div id="trending">
          <SectionHeader title="Trending now" subtitle="What shoppers are loving this week" to="/shop?sort=rating" />
        </div>
        <ProductGrid products={trending} loading={loading} skeletonCount={4} />
      </section>

      {/* Deals */}
      <section aria-labelledby="deals" className="rounded-3xl bg-brand-50 p-5 sm:p-8 dark:bg-brand-900/10">
        <div id="deals">
          <SectionHeader title="Biggest savings" subtitle="Highest discounts in the store today" />
        </div>
        <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-semibold text-brand-700 dark:bg-slate-900 dark:text-brand-300">
          <BadgePercent className="h-4 w-4" aria-hidden="true" /> Use code WELCOME10 for 10% off at checkout
        </div>
        <ProductGrid products={deals} loading={loading} skeletonCount={4} />
      </section>

      {/* Recently viewed */}
      {recent.length > 0 && (
        <section aria-labelledby="recent">
          <div id="recent">
            <SectionHeader title="Recently viewed" />
          </div>
          <ProductGrid products={recent} />
        </section>
      )}
    </div>
  )
}

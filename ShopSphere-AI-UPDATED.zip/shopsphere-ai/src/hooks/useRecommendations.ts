import { useMemo } from 'react'
import { useBehaviorStore } from '../store/userBehaviorStore'
import { useCartStore } from '../store/cartStore'
import { useOrderStore } from '../store/orderStore'
import { useWishlistStore } from '../store/wishlistStore'
import type { Product } from '../types'
import { recommend, type Recommendation } from '../utils/recommendations'

export function useRecommendations(products: Product[], limit = 8) {
  const events = useBehaviorStore((s) => s.events)
  const cartItems = useCartStore((s) => s.items)
  const wishlistIds = useWishlistStore((s) => s.ids)
  const orders = useOrderStore((s) => s.orders)

  return useMemo(() => {
    const purchasedIds = orders.flatMap((o) => o.items.map((i) => i.productId))
    const picks: Recommendation[] = recommend(
      products,
      {
        events,
        cartIds: cartItems.map((i) => i.productId),
        wishlistIds,
        purchasedIds,
      },
      limit,
    )
    const personalised = events.length > 0 || cartItems.length > 0 || wishlistIds.length > 0 || orders.length > 0
    return { picks, personalised }
  }, [products, events, cartItems, wishlistIds, orders, limit])
}

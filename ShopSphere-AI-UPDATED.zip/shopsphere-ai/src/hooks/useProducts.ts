import { useEffect, useState } from 'react'
import { getProducts } from '../api/products'
import type { Product } from '../types'

// Loaded once, then shared by every page so navigation feels instant.
let cache: Product[] | null = null
let inflight: Promise<Product[]> | null = null

export function useProducts() {
  const [products, setProducts] = useState<Product[]>(cache ?? [])
  const [loading, setLoading] = useState(cache === null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (cache) return
    let active = true
    if (!inflight) inflight = getProducts()
    inflight
      .then((result) => {
        cache = result
        if (active) {
          setProducts(result)
          setLoading(false)
        }
      })
      .catch(() => {
        inflight = null
        if (active) {
          setError('Could not load products. Please try again.')
          setLoading(false)
        }
      })
    return () => {
      active = false
    }
  }, [])

  return { products, loading, error }
}

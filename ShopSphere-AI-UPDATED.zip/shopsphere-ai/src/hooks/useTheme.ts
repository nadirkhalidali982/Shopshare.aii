import { useEffect } from 'react'
import { useUiStore } from '../store/uiStore'

/** Keeps the <html class="dark"> flag in sync with the saved theme. Call once in App. */
export function useTheme() {
  const theme = useUiStore((s) => s.theme)
  const toggleTheme = useUiStore((s) => s.toggleTheme)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  return { theme, toggleTheme }
}

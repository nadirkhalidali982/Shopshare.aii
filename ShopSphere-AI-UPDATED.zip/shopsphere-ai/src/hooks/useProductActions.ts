import { useCallback } from 'react'
import { MAX_QTY, useCartStore } from '../store/cartStore'
import { useUiStore } from '../store/uiStore'
import { useBehaviorStore } from '../store/userBehaviorStore'
import { useWishlistStore } from '../store/wishlistStore'
import type { Product } from '../types'

/** Shared "add to cart" and "wishlist" behaviour with tracking and toasts. */
export function useProductActions() {
  const addItem = useCartStore((s) => s.addItem)
  const toggle = useWishlistStore((s) => s.toggle)
  const track = useBehaviorStore((s) => s.track)
  const toast = useUiStore((s) => s.pushToast)

  const addToCart = useCallback(
    (product: Product, quantity = 1): boolean => {
      if (product.stock <= 0) {
        toast('Sorry, this item is out of stock', 'error')
        return false
      }
      addItem(product.id, quantity, Math.min(MAX_QTY, product.stock))
      track(product.id, 'cart')
      toast(`${product.name} added to cart`)
      return true
    },
    [addItem, track, toast],
  )

  const toggleWishlist = useCallback(
    (product: Product) => {
      const added = toggle(product.id)
      if (added) {
        track(product.id, 'wishlist')
        toast('Saved to your wishlist')
      } else {
        toast('Removed from wishlist', 'info')
      }
    },
    [toggle, track, toast],
  )

  return { addToCart, toggleWishlist }
}
